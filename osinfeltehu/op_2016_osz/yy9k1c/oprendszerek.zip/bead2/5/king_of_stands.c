#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include "visitor_list.h"
#include "event_list.h"

void handler(int signumber) {}

int main()
{
	int pipefd[2];
	
	if (pipe(pipefd) == -1)
	{
		perror("Hiba a cső nyitásakor.\n");
		exit(EXIT_FAILURE);
	}
	
	signal(SIGUSR1, handler);
	
	pid_t pid = fork();
	
	if (pid != 0) // parent, organizer
	{
		struct visitor_node visitors;
		visitors.next = NULL;
		const char visitor_file[] = "visitors_data.bin";
		load_visitors(&visitors, visitor_file);
		
		struct event_node events;
		events.next = NULL;
		const char event_file[] = "events_data.bin";
		load_events(&events, event_file);
		
		organize_events(events.next, visitors.next);
	}
	else // child, partner
	{
		char buffer[100];
		read(pipefd[0], buffer, 100);
		printf("[Pnr] Megyek a rendezvény helyszínére: %s.\n", buffer);
		
		sleep(1);
		kill(getppid(), SIGUSR1);
		
		pause();
		
		int headcount;
		read(pipefd[0], &headcount, sizeof(headcount));
				
		puts("\n[Pnr] A résztvevők:");
		
		int i;
		const char* blacklist[headcount];
		srand(time(NULL));
		int not_appeared = 0;
		for (i = 0; i < headcount; ++i)
		{
			int string_size;
			read(pipefd[0], &string_size, sizeof(string_size));
			read(pipefd[0], buffer, string_size);
			puts(buffer);
			
			if (rand() % 10 == 0)
			{
				blacklist[not_appeared] = (const char*)malloc(strlen(buffer) + 1);
				strcpy((char*)blacklist[not_appeared++], buffer);
			}
		}
		puts("");
		
		close(pipefd[0]);
		
		int success = rand() % 21 * 5;
		write(pipefd[1], &success, sizeof(success));
		
		write(pipefd[1], &not_appeared, sizeof(not_appeared));
		for (i = 0; i < not_appeared; ++i)
		{
			int string_size = strlen(blacklist[i]) + 1;
			write(pipefd[1], &string_size, sizeof(string_size));
			write(pipefd[1], blacklist[i], string_size);
			free((char*)blacklist[i]);
		}

		close(pipefd[1]);
		
		sleep(1);
		kill(getppid(), SIGUSR1);
	}
}

void organize_events(struct event_node* events, struct visitor_node* visitors, int pipefd[])
{
	for (; events != NULL; events = events->next)
	{
		write(pipefd[1], events->location, sizeof(events->location));
		
		pause();
		puts("[KoS] Jól van, a helyeden vagy.");
		
		send_participants(events->id, visitors);
	}
	
	int headcount = 4;
	
	write(pipefd[1], &headcount, sizeof(headcount));
	
	int string_size = strlen("Kovács Lajos") + 1;
	write(pipefd[1], &string_size, sizeof(string_size));
	write(pipefd[1], "Kovács Lajos", string_size);
	string_size = strlen("Kis Róbert") + 1;
	write(pipefd[1], &string_size, sizeof(string_size));
	write(pipefd[1], "Kis Róbert", string_size);
	string_size = strlen("Szabó Anikó") + 1;
	write(pipefd[1], &string_size, sizeof(string_size));
	write(pipefd[1], "Szabó Anikó", string_size);
	string_size = strlen("Nagy Dóra") + 1;
	write(pipefd[1], &string_size, sizeof(string_size));
	write(pipefd[1], "Nagy Dóra", string_size);
	// fflush(NULL);
	
	close(pipefd[1]);
	
	sleep(1);
	kill(pid, SIGUSR1);
	
	pause();
	
	int success;
	read(pipefd[0], &success, sizeof(success));
	printf("[KoS] Azt a visszajelzést kaptam, hogy a rendezvény %i%%-ban volt sikeres, és ezek a jelentkezettek nem jelentek meg:\n", success);
	
	int i;
	int not_appeared;
	read(pipefd[0], &not_appeared, sizeof(not_appeared));
	for (i = 0; i < not_appeared; ++i)
	{
		read(pipefd[0], &string_size, sizeof(string_size));
		char buffer[100];
		read(pipefd[0], buffer, string_size);
		puts(buffer);
	}
	puts("");
	
	close(pipefd[0]);

	waitpid(pid);
	
	puts("[KoS] Nézzük a következő eseményt…");
}