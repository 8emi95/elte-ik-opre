#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/ipc.h>
#include <mqueue.h>

void parent(char* ch);
void handler(int signalnumber)
{
	printf("A partner megerkezett\n");
}

int main()
{
	char ch[100] = {"itt"};
	
	parent(ch);

	return 0;
}

void parent(char* ch)
{

	int pipefd[2]; 
	pid_t chpid;
	char sz[100]; 
	
	if (pipe(pipefd) == -1)
	{
		perror("Hiba a pipe nyitaskor!");
		exit(EXIT_FAILURE);
	}
	
	signal(SIGUSR1,handler);
	
	chpid = fork();
	if (chpid == -1)
	{
		perror("Fork hiba");
		exit(EXIT_FAILURE);
	}
	
	
	if (chpid == 0)
	{	
		printf("Gerek indul\n");
		sleep(3);
		close(pipefd[1]);
		read(pipefd[0],sz,sizeof(sz));
		printf("Gyerek olvasta uzenet: %s\n",sz);
		close(pipefd[0]);
		
		printf("Utazas 3 masodperc\n");
		sleep(3);
		printf("Megerkezett\n");
		
		
		
		kill(getppid(),SIGUSR1);
		
		printf("Gerek vege\n");
	} 
	else
	{ 
		printf("Szulo indul\n");
		close(pipefd[0]);
		write(pipefd[1], ch,sizeof(ch));
		close(pipefd[1]);
		fflush(NULL);
		
		pause();
		
		
		
		printf("Szulo vege\n");
	}
	
	
}