#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <signal.h>

void flushBuffer()
{
	int c;
	if(!feof(stdin))
		while((c = getchar()) != '\n' && c != EOF);
}

void trimStrEnd(char *str)
{
	char *ch = str + strlen(str) - 1;
	*ch = '\0';
}		

char* searchLineByBegining(char* str, FILE *f)
{
	char line[300];
	char* ret;
	while(!feof(f))
	{
		fgets(line, sizeof(line), f);
		if ( strncmp(str,line,strlen(str)) == 0)
		{	
			char *ret = line;
			return ret;
		}
	}
	return NULL;
}

char* getDataByID(int ID, FILE *f)
{
	char line[300];
	int currID;
	while (!feof(f))
	{
		char *ret = line;
		fgets(line, sizeof(line), f);
		currID = atoi(line);
		if (currID == ID)
			return ret;
	}
	return NULL;
}

int countLinesByID(int ID, FILE *f)
{
	char line[300];
	int currID;
	int count = 0;
	while(fgets(line, sizeof(line), f))
	{
		currID = atoi(line);
		if (currID == ID)
			++count;
	}
	return count;
}

void deleteVisitor()
{
	printf("===================\n");
	fflush(stdin);
	flushBuffer();
	FILE *old, *new;
	int visitorID;
	char line[200];
	printf("Adja meg a torlendo szemely azonositojat: ");
	scanf("%d",&visitorID);
	//
	// VISITOR.TXT karbantartása
	//
	old = fopen("VISITOR.TXT","r");
	if (old == NULL)
	{
		perror("Hiba a VISITOR.TXT megnyitasa kozben!\n");
		exit(1);
	}
	remove("VISITOR.TEMP");
	new = fopen("VISITOR.TEMP","w");
	while(fgets(line, sizeof(line), old))
	{
		if ( atoi(line) != visitorID )	fprintf(new,line);
	}
	fclose(old);
	fclose(new);
	remove("VISITOR.TXT");
	rename("VISITOR.TEMP", "VISITOR.TXT");
	//
	// VISITS.TXT karbantartása
	//
	old = fopen("VISITS.TXT","r");
	if (old == NULL)
	{
		perror("Hiba a VISITS.TXT megnyitasa kozben!\n");
		exit(1);
	}
	new = fopen("VISITS.TEMP","w");
	while(fgets(line, sizeof(line), old))
	{
		char *token = strtok(line,"\t");
		int eventID = atoi(token);
		token = strtok(NULL, "\t");
		if (token == NULL) break;
		int currVisitorID = atoi(token);
		token = strtok(NULL, "\t");
		char *date = token;
		if (currVisitorID != visitorID) fprintf(new,"%d\t%d\t%s\n", eventID, currVisitorID, date);
	}
	fclose(old);
	fclose(new);
	remove("VISITS.TXT");
	rename("VISITS.TEMP", "VISITS.TXT");
}

void deleteEvent()
{
	printf("====================\n");
	fflush(stdin);
	flushBuffer();
	FILE *old, *new;
	int eventID;
	char line[300];
	printf("Adja meg a torlendo rendezveny azonositojat: ");
	scanf("%d",&eventID);
	//
	// EVENT.TXT karbantartása
	//
	old = fopen("EVENT.TXT","r");
	if (old == NULL)
	{
		perror("Hiba az EVENT.TXT megnyitasa kozben!\n");
		exit(1);
	}
	remove("EVENT.TEMP");
	new = fopen("EVENT.TEMP","w");
	while(fgets(line, sizeof(line), old))
	{
		if ( atoi(line) != eventID )	fprintf(new,line);
	}
	fclose(old);
	fclose(new);
	remove("EVENT.TXT");
	rename("EVENT.TEMP", "EVENT.TXT");
	//
	// VISITS.TXT karbantartása
	//
	old = fopen("VISITS.TXT","r");
	if (old == NULL)
	{
		perror("Hiba a VISITS.TXT megnyitasa kozben!\n");
		exit(1);
	}
	new = fopen("VISITS.TEMP","w");
	while(fgets(line, sizeof(line), old))
	{
		char *token = strtok(line,"\t");
		int currEventID = atoi(token);
		token = strtok(NULL, "\t");
		if (token == NULL) break;
		int visitorID = atoi(token);
		token = strtok(NULL, "\t");
		char *date = token;
		if (currEventID != eventID) fprintf(new,"%d\t%d\t%s\n", currEventID, visitorID, date);
	}
	fclose(old);
	fclose(new);
	remove("VISITS.TXT");
	rename("VISITS.TEMP", "VISITS.TXT");
}

void listAssignees(int eventID)
{
	printf("A megadott rendezvenyre jelentkezok adatai:\n -- Lista eleje --\n");
	FILE *visits, *visitor;
	visits = fopen("VISITS.TXT","r");
	if (visits == NULL)
	{
		perror("Hiba a VISITS.TXT megnyitasa kozben!\n");
		exit(1);
	}
	char line[100];
	while (!feof(visits))
	{
		fgets(line, sizeof(line), visits);
		char *token = strtok(line, "\t");
		int currEvent = atoi(token);
		token = strtok(NULL, "\t");
		if (token == NULL) break;
		int currVisitor = atoi(token);
		if ( currEvent == eventID )
		{
			visitor = fopen("VISITOR.TXT","r");
			if (visitor == NULL)
			{
				perror("Hiba a VISITOR.TXT megnyitasa kozben!\n");
				fclose(visits);
				exit(1);
			}
			printf( getDataByID(currVisitor, visitor) );
			fclose(visitor);
		}
	}
	printf(" -- Lista vege --\n");
	fclose(visits);
}

void handler(int signumber)
{
	printf("HANDLER: Jelzes erkezett: %i\n", signumber);
}

int main()
{
	printf("King of Stands lebonyolitas\n");
	signal(SIGRTMIN, handler);
	int status;
	int pipefd[2];
	char sz[300];
	char eventData[4][300];
	if (pipe(pipefd) == -1)
	{
		perror("Hiba a pipe nyitaskor!");
    	exit(EXIT_FAILURE);
	}
	pid_t child = fork();
	if (child < 0)
	{
		perror("Hiba a gyerekfolyamat letrehozasa kozben!\n");
		exit(1);
	}
	if (child > 0)
	{
		printf("Szulofolyamat elindult!\n");

		// EVENT.TXT megnyitasa es a rendezveny kiolvasasa

		FILE *events = fopen("EVENT.TXT", "r");
		if (events == NULL)
		{
			perror("Hiba az EVENT.TXT fajl megnyitasa kozben!");
			exit(1);
		} 
		char line[300];
		fgets(line, sizeof(line), events);
		char *eventTok = strtok(line, " \t");
		int i=0;
		while(eventTok != NULL)
		{
			strcpy(eventData[i], eventTok);
			eventTok = strtok(NULL, " \t");
			++i;
		}
		printf("Szulo: a rendezveny helyszine: %s\n", eventData[3]);
		fclose(events);

		// A rendezveny helyszinenek bepakolasa a csobe

		write(pipefd[1], eventData[3], strlen(eventData[3])-1);

		// Gyerekfolyamat bevarasa

		pause();
		printf("Szulo: megkaptam a gyerekfolyamat jelzeset!\n");

		// A rendezveny resztvevoinek bepakolasa a csobe

		write(pipefd[1], eventData[0], strlen(eventData[0]));
		printf("Szulo: elkuldtem a gyereknek a rendezveny resztvevoit!\n");

		// Kiolvassuk, mennyire volt sikeres a rendezveny

		pause();

		int success;
		read(pipefd[0], &success, sizeof(success));
		printf("Szulo: a rendezveny sikeressege: %i \%\n", success);

		waitpid(child, &status, 0);
		printf("Szulo: a gyerekfolyamat veget ert!\n");
		close(pipefd[1]);
		close(pipefd[0]);
	}
	else
	{
		printf("Gyerek: elindultam!\n");

		// A gyerek kiolvassa csobol, hogy hova kell mennie

		read(pipefd[0], sz, sizeof(eventData[3]-1));
		printf("Gyerek: Elindultam ide: %s\n", sz);

		// A gyerek ertesiti a szulot, hogy odaert

		printf("Gyerek: Megerkeztem!\n");
		kill(getppid(), SIGRTMIN);

		// A rendezveny resztvevoinek listazasa

		read(pipefd[0], sz, sizeof(eventData[0]));
		printf("Gyerek: megkaptam a szulotol a resztvevoket:\n");
		int eventID = atoi(sz);
		listAssignees(eventID);
		FILE *visits = fopen("VISITS.TXT", "r");
		int participants = countLinesByID(eventID, visits);
		fclose(visits);
		printf("Gyerek: osszesen %i embert varunk a rendezvenyre.\n", participants);
		printf("Gyerek: megvarom a rendezveny veget...\n");

		// A rendezveny lebonyolitasa

		// Hany szazalekban volt sikeres a rendezveny

		srand(time(NULL));
		int success = rand() % 101;
		write(pipefd[1], &success, sizeof(success));
		printf("Gyerek: elkuldtam a szulonek, hogy mennyire volt sikeres a rendezveny!\n");
		kill(getppid(), SIGRTMIN);

		close(pipefd[0]);
		close(pipefd[1]);
	}
	return 0;
}
