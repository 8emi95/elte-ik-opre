#include <stdio.h>
#include "vector.h"
#include "type_handlers.h"
#include "read_write.h"
#include "controller.h"
int main(int argc, char ** args){
	
	vector* users=malloc(sizeof(vector));
	vector_new(users,sizeof(User),&User_freefunct,&User_equals,&User_lister);
	vector* events=malloc(sizeof(vector));
	vector_new(events,sizeof(Event),&Event_freefunct,&Event_equals,&Event_lister);
	
	DB db;
	db.users=users;
	db.events=events;
	db.filename="db";
	read_data_base(db);
	menu_inic();
	
	while(run_menu(db));
	
	
	
	free(users);
	free(events);
  return 0;
}
