#ifndef H_VAR_TYPES
#define H_VAR_TYPES

#include "vector.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

enum {User_type=1,Event_type=2} data_type;

typedef struct data_base{
	vector* users;
	vector* events;
	char* filename;
}DB;

typedef struct{
  char* name;
  char* email;
  int event_id;
} User;

typedef struct{
  int id;
} Event;

/*0 ha sikertelen , -1 ha oprendszer miatt sikertelen*/

int User_create(DB *db,char name[20], char email[255],int event_id);
	
	/*-1 oprendszer hiba, 0 létezik már ijen id-jű*/
int Event_create(DB *db,int event_id);
#endif
