#ifndef __CDS_VECTOR_H
#define __CDS_VECTOR_H

typedef void (*freeFunction)(void *);
typedef enum { FALSE, TRUE } bool;

typedef struct {
	void *elements;
	int elementSize;
	int allocatedLength;
	int logicalLength;
	freeFunction freeFn;
	int (*equals)(void* ,void*);
	void (*lister)(void*,bool);
	//void (*freeFn)(void *);
} vector;

void vector_new(vector *vector, int elementSize, freeFunction freeFn,int (*equals)(void* ,void*),void (*lister)(void*,bool));
void vector_destroy(vector *vector);
int vector_size(vector *vector);
void *vector_address(vector *vector, int index);

void vector_add(vector *vector, void *element);
void vector_item_at(vector *vector, int index, void *target);
void vector_insert_at(vector *vector, int index, void *target);
void vector_remove_at(vector *vector, int index);
int vector_find(vector* find_in,void* find_this,int *ret_index);
void vector_list(vector*,bool);
void vector_remove(vector* ,void*);

#endif
