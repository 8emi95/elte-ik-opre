#ifndef H_TYPE_HANDLERS
#define H_TYPE_HANDLERS
#include <stdlib.h>
#include "var_types.h"
#include <string.h>
/*int (*comparator)(void* current,void* this) a szintaxis,!=0 => egyenlő, 0=>ha nem*/

int User_equals(void* current, void* this){
		User* c=current;
		User* t=this;
		return !(strcmp(c->name,t->name));
}
int Event_equals(void* current,void* this){
	Event* c=current;
	Event* t=this;
	return c->id==t->id;
}

void User_lister(void* user,bool print_type){
	User* u=user;
	if(print_type)
		printf("%d %s %s %d\n",User_type,u->name,u->email,u->event_id);
	else
	printf("%s %s %d\n",u->name,u->email,u->event_id);
}

void Event_lister(void* event,bool print_type){
	Event* e=event;
	if(print_type)
	printf("%d %d\n",Event_type,e->id);
	else
	printf("%d\n",e->id);
}
void Event_freefunct(void* event){
}

void User_freefunct(void* user){
	User* u=user;
	free(u->name);
	free(u->email);	
}

#endif
