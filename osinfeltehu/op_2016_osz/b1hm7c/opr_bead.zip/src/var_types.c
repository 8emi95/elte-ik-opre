#include "var_types.h"	
int Event_create(DB *db,int event_id){
				int index;
				Event* e=(Event*)malloc(sizeof(Event));
				if(e){
					e->id=event_id;
					if(vector_find(db->events,e,&index)){
						free(e);
						return 0;
					}else
					vector_add(db->events,e);
					return 1;
				}
				return -1;

}

int User_create(DB *db,char* name,char* email,int event_id){
				size_t name_length=strlen(name)+1U;
				size_t email_length=strlen(name)+1U;
				int index;
				Event e;
				
				e.id=event_id;
				
				if(!vector_find(db->events,&e,&index)){
					
					return 0;
				}
				
				User* ret=malloc(sizeof(User));
				
				if(ret){
					
					ret->name=calloc(name_length,sizeof(char));
					if(!(ret->name)){						
						free(ret);
						return -2;
					};
					ret->email=calloc(email_length,sizeof(char));
					if(!(ret->email)){
						free(ret->name);
						free(ret); 
						return -2;
					}
					strcpy(ret->name,name);
					strcpy(ret->email,email);
					ret->event_id=event_id;
					
					if(vector_find(db->users,ret,&index)){
						free(ret->name);
						free(ret->email);
						free(ret);
						ret=NULL;
						return -1;
						
					}
					
					vector_add(db->users,ret);
					return db->users->logicalLength;
				}
				return -2;
				
	}
	
	
