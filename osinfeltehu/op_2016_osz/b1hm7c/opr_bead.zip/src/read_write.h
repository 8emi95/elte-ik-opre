#ifndef H_READ_WRITE
#define H_READ_WRITE
#include "vector.h"
#include "var_types.h"
#include <stdio.h>

void write_data_base(DB db);
int read_data_base(DB db);
 



#endif
