#ifndef H_CONTROLLER
#define H_CONTROLLER
#include <stdio.h>
#include "var_types.h"
#include "read_write.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int list_Users(DB db, char* error);
int new_User(DB db,char* error);
int mod_User(DB db, char* error);
int start_Event(DB db, char* error);
int close_Event(DB db, char* error);
int list_Events(DB db,char* error);
int (*controll_functions[6])(DB db,char *error);
static char * console_getline(void);


int menu_inic();
int run_menu(DB db);



#endif
