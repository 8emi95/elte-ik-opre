#include "read_write.h"
void write_data_base(DB db){
	vector_list(db.events,FALSE);
	vector_list(db.users,FALSE);
}

#include "vector.h"

int read_data_base(DB db){
	
	FILE* file= fopen( db.filename, "r" );
	if (file){
		char line_buffer[1000];
		while(fgets(line_buffer,sizeof(line_buffer),file)!= NULL){
			char name[300],email[500];
			int event_id;
			int parsed=sscanf(line_buffer,"%s %s %d",name,email,&event_id);
			if(parsed ==1){
				Event_create(&db,atoi(name));
			}else if(parsed ==3){
				User_create(&db,name,email,event_id);
			}
		}
		fclose(file);
		return -1;
	}
	
	return 0;
}
