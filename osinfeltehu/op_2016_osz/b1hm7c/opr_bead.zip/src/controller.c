#include "controller.h"
 
 int menu_inic(){
controll_functions[0]=list_Users;
controll_functions[1]=new_User;
controll_functions[2]=mod_User;
controll_functions[3]=start_Event;
controll_functions[4]=close_Event;
controll_functions[5]=list_Events;
return 1;
}
 
int mod_User(DB db, char* error){
	printf("Látogató adatainak módosítása\n Kérem adja meg a módosítandó látogató nevét(Egyben): \n");
	fflush(stdout);
	while ( getchar() != '\n' );
	char name[300];
	char dummy[300];
	char* line;
	fseek(stdin,0,SEEK_END);
	line=console_getline();
	if(sscanf(line,"%s %s",name,dummy)!=1){
		strcpy(error,"Nem adott meg semmit, vagy nem egyben adta meg a nevet!");
		return 0;
	}
	User dummy_user;
	int selected_user;
	size_t name_length=strlen(name)+1U;
	dummy_user.name=calloc(name_length,sizeof(char));
	strcpy(dummy_user.name,name);
	int message = vector_find(db.users,&dummy_user,&selected_user);
	if(!message){
		strcpy(error,"Nincs ilyen nevű látogató!");
		return 0;
	}else{
		printf("Adja meg a látogató új e-mail címét:\n(Egyszó)");
		fflush(stdout);
			char email[500];
			char dummy_email[500];
			free(line);
			fseek(stdin,0,SEEK_END);
			line=console_getline();
			if(sscanf(line,"%s %s",email,dummy_email)!=1){
				strcpy(error,"Nem egy szóban adta meg a felhasználó új emailjét!");
				return 0;
			}
			User* u = vector_address(db.users,message);
			free(u->email);
			u->email=calloc(strlen(email)+1U,sizeof(char));
			strcpy(u->email,email);
			free(line);
			return 2;
		}
	}
 
int start_Event(DB db, char* error){
	printf("Új Esemény indítása \n Kére irja be az új esemény azonosító számát: (Szám)\n");
	fflush(stdout);
	 while ( getchar() != '\n' );
	int event_id;
	int dummy_int;
	char* line;
	char c;
	fseek(stdin,0,SEEK_END);
	line=console_getline();
	if(sscanf(line,"%d %d",&event_id,&dummy_int)!=1){
		strcpy(error,"Nem egy számot adott meg!");
		return 0;
	}
	int message=Event_create(&db,event_id);
	switch(message){
		case 1:
			return 2;
		break;
		case 0:
			strcpy(error,"Már létezik ilyen azonostójú esemény!");
			return 0;
		break;
		case -1:
			strcpy(error,"A rendszer nemtudta lefoglalni a tárterületet az Eseménynek!");
			return 0;
		break;
		default:
			strcpy(error,"Váratlan hiba!");
			return 0;
		break;
	};
}

int close_Event(DB db, char* error){
	printf("Esemény törlése \n Kérem irja be a törlendő esemény azonosító számát: (Szám) \n");
	fflush(stdout);
	while ( getchar() != '\n' );
	int event_id;
	int dummy_int;
	char* line;
	fseek(stdin,0,SEEK_END);
	line=console_getline();
	if(sscanf(line,"%d %d",&event_id,&dummy_int)!=1){
		strcpy(error,"Nem egy számot adott meg!");
		free(line);
		return 0;
	}
	free(line);
	Event dummy_event;
	dummy_event.id=event_id;
	vector_remove(db.events,&dummy_event);
	
	int j;
	User current;
	for(j=0;j<db.users->logicalLength;j++){
		vector_item_at(db.users,j,&current);
		if(current.event_id==dummy_event.id){
			vector_remove(db.users,&current);
		}
	}
	
	return 2;
}

int list_Events(DB db,char* error){
	printf("Az események listája: \n");
	fflush(stdout);
	vector_list(db.events,FALSE);
	return 1;
}

int list_Users(DB db, char* error){
	printf("Felhasználók listája:\n (Név,Email cím,Esemény azonostója)\n");
	fflush(stdout);
	vector_list(db.users,FALSE);
	return 1;	
}
int new_User(DB db,char* error){
	printf("Új Látogató regisztrációja:\n Kérem adja meg a látogató nevét: \n(Egy szóban esetleg \"_\" elválasztással)\n");
	fflush(stdout);
	while ( getchar() != '\n' );
	char name[300];
	char dummy[300];
	char* line;
	fseek(stdin,0,SEEK_END);
	line=console_getline();
	if(sscanf(line,"%s %s\n",name,dummy)!=1){
		strcpy(error,"Nem adott meg semmit, vagy nem egyben adta meg a nevet!");
		free(line);
		return 0;
	}
	printf("Kérem adja meg az e-mail címét:(egyben)\n");
	fflush(stdout);
	char email[500];
	free(line);
	fseek(stdin,0,SEEK_END);
	line=console_getline();
	if(sscanf(line,"%s %s",email,dummy)!=1){
		strcpy(error,"Nem adott meg semmit, vagy nem egyben adta meg az email címet!");
		free(line);
		return 0;
	}
	printf("Kérem adja meg a rendezvény azonosítót ahova jelentkezik:(számot!) \n");
	fflush(stdout);
	int event_id;
	int dummy_int;
	free(line);
	fseek(stdin,0,SEEK_END);
	line=console_getline();
	if(sscanf(line,"%d %d",&event_id,&dummy_int)!=1){
		strcpy(error,"Nem egy számot adott meg!");
		free(line);
		return 0;
	}
	free(line);
	int message = User_create(&db,name,email,event_id);
	if(message<=0){
		switch(message){
			case 0:
				strcpy(error,"Nem létezik ilyen azonosítójú rendezvény!");
			break;
			case -1:
				strcpy(error,"Ilyen nevű látogató már jelentkezett!");
			break;
			case -2:
				strcpy(error,"Hiba történt a rendszerben (User adattagjai lefoglalása közben)!");
			break;
			default:
				strcpy(error,"Váratlan hiba történt!");
			break;
		}
			return 0;
	}
	printf("Az %d. látogató regisztrált.",message);
	fflush(stdout);
	return 2;
	
}

int run_menu(DB db){
	static int wait;
	static pid_t pt;
	
	printf("Üdvözlet a King of Stands nyilvántartásában!");
	printf("Kérem válassza ki mit szeretne tenni:\n(A számokon kívüli más érték megadása kilépést jelent) \n \"1\".:Jelentkezettek listázása. \n \"2\".:Látogató regisztráció. \n \"3\".:Látogató adatainak módosítása. \n \"4\".:Rendezvény idítása. \n \"5\".:Rendezvény törlése.\n  \"6\".:Rendezvények listázása.\n \t Választása: ");
	fflush(stdout);
	int prev_wait=wait;
	int i;
	fseek(stdin,0,SEEK_END);
	scanf("%d",&i);
	if(i<1||i>6){
	return 0;
	}else{
	fseek(stdin,0,SEEK_END);
	char* error=calloc(1024,sizeof(char));
	wait=(*controll_functions[i-1])(db,error);
	if(!wait){
		printf(" \n HIBA:\n     %s \n",error);
		fflush(stdout);
	}
	if(prev_wait){
		int return_stat;
		waitpid(pt,&return_stat,0);
	}
	if(wait==2){
		pt=fork();
		if(pt==0){
			freopen(db.filename,"w",stdout);
			write_data_base(db);
			exit(0);
		}
	}else{
		wait=0;
	}
	free(error);
}
	
	
	return 1;
}

static char * console_getline(void) {
    char * line = malloc(100), * linep = line;
    size_t lenmax = 100, len = lenmax;
    int c;

    if(line == NULL)
        return NULL;

    for(;;) {
        c = fgetc(stdin);
        if(c == EOF)
            break;

        if(--len == 0) {
            len = lenmax;
            char * linen = realloc(linep, lenmax *= 2);

            if(linen == NULL) {
                free(linep);
                return NULL;
            }
            line = linen + (line - linep);
            linep = linen;
        }

        if((*line++ = c) == '\n')
            break;
    }
    *line = '\0';
    return linep;
}
