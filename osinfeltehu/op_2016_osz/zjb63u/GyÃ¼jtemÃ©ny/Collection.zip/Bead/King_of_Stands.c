/*
Egy kiállításokat, rendezvényeket szervező társaság a "King of Stands",
elektronikus látogatói nyilvántartást készített. A látogatók a nyilvántartásba
jelentkezéskor megadják nevüket, mail címüket, a rendezvény azonosító számát!
Az elektronikus rendszer a jelentkezés nyugtázásaként visszaadja,
hogy hányadik vendégként történt meg a regisztráció!
Az alkalmazás adjon lehetőséget vendég jelentkezéshez, a jelentkezettek listázásához,
egy vendég adatainak módosításához, törléséhez. Legyen lehetőségünk egy új rendezvény indításához,
egy rendezvény összes adatának törléséhez! A jelentkezőknél a korábbi adatok mellett
rögzítsük automatikusan a jelentkezési időt(rendszeridő) is(ezt nem kell bekérni)!
Készítsünk C programot, amellyel a leírt tevékenység elvégezhető. Az adatokat fájlban tároljuk.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define MAX_SIZE 512

void menu();
void rendezveny_inditasa();
void jelentkezes();
void listazas();
void torles();
void modositas();
void rendezveny_torlese();
void copy_file();
void copy_file_rend();

int main(int argc,char *argv[])
{
	
	menu();
	
	return 0;
}

void menu()
{
	char menup[MAX_SIZE];
	
	system("clear");
	
	while(1)
	{
		printf("===========================================================\n");
		printf("Udvozoljuk a King of stands nyilvantartasaban\n");
		printf("Az alabb felsorolt lehetosegek allnak rendelkezesere:\n");
		printf("(1) \tJelentkezes egy rendezvenyre\n");
		printf("(2) \tRendezvenyek listazasa\n");
		printf("(3) \tRendezvenyre jelentkezett szemely adatainak modositasa\n");
		printf("(4) \tRendezvenyre jelentkezett szemely torlese\n");
		printf("===========================================================\n");
		printf("(5) \tUj rendezveny inditasa\n");
		printf("(6) \tRendezveny torlese\n");
		printf("A nyilvantartas bezarasahoz nyomja meg CTRL + C kombinaciot\n>");
		scanf("%s",menup);
		printf("===========================================================\n");
			
			if( strcmp(menup,"1") == 0 )
			{
				jelentkezes();
			}
			else if( strcmp(menup,"2") == 0 )
			{
				listazas();
				char temp[MAX_SIZE];
				printf("\nFolytatashoz nyomjon ENTER-t\n>");
				scanf("%s",temp);
				system("clear");
			}
			else if( strcmp(menup,"3") == 0 )
			{
				modositas();
				system("clear");
				printf("A modositas sikeresen befelyezodott\n");
			}
			else if( strcmp(menup,"4") == 0 )
			{
				torles();
				system("clear");
				printf("A torles sikeresen befelyezodott\n");
			}
			else if( strcmp(menup,"5") == 0 )
			{
				rendezveny_inditasa();
				system("clear");
				printf("A rendezveny inditasa sikeresen befelyezodott\n");
			}
			else if( strcmp(menup,"6") == 0 )
			{
				rendezveny_torlese();
				system("clear");
				printf("A rendezveny torlese sikeresen befelyezodott\n");
			}
			else
			{
				char temp[MAX_SIZE];
				printf("Nem definialt menupont, folytatashoz nyomjon ENTER-t\n>");
				scanf("%s",temp);
				menu();
			}
	}
}

void rendezveny_inditasa()
{
	FILE *rendezveny;
	rendezveny = fopen("rendezveny.txt","a+");
	
	char id[MAX_SIZE]; 		//azonosító
	char title[MAX_SIZE]; 	//rendezvény neve
	
	printf("Addja meg a rendezveny adatait:");
	printf("\nRendezveny azonositoja:\t");
	scanf("%s",id);
	printf("\nRendezveny neve:\t");
	scanf("%s",title);
	
	fprintf(rendezveny,"%s %s\n",id,title);
	fclose(rendezveny);
}

void jelentkezes()
{
	FILE *jelentkezettek;
	jelentkezettek = fopen("jelentkezettek.txt","a+");
	
	char name[MAX_SIZE];	//jelentkező neve
	char mail[MAX_SIZE];	//jelentkező e-mail címe
	char id[MAX_SIZE];		//rendezveny azonosítója
	time_t rawtime;
	struct tm * timeinfo;
	char buffer[26];

	
	
	printf("Addja meg az adatait!");
	printf("\nNeve (Szóköz helyett alsovonas: _ ):\t");
	scanf("%s",name);
	printf("\nE-mail cime:\t");
	scanf("%s",mail);
	printf("\nRendezveny azonositoja:\t");
	scanf("%s",id);
	time ( &rawtime );
	timeinfo = localtime ( &rawtime );
	strftime(buffer, 26, "%Y-%m-%d %H:%M:%S", timeinfo);
	
	fprintf(jelentkezettek,"%s %s %s %s\n",name,mail,id,buffer);
	fclose(jelentkezettek);
	
	//sorszám kiszámitása
	
	jelentkezettek = fopen("jelentkezettek.txt","r");
	char line[MAX_SIZE];
	int number = 0;
	
	while(fgets(line,sizeof(line),jelentkezettek) != NULL)
	{
		char n_name[MAX_SIZE];  	//  név
		char n_mail[MAX_SIZE];  	//  e-mail
		char n_id[MAX_SIZE];  		//  rendezvényazonosító				
		char date[MAX_SIZE];		//  rendszeridő dátum
		char time[MAX_SIZE];		//  rendszeridő idő

		sscanf(line,"%s %s %s %s %s",n_name,n_mail,n_id,date,time);

		
		if( strcmp(id,n_id) == 0 )
		{
			number++;
		}
	}
	
	fclose(jelentkezettek);
	
	system("clear");
	printf("\nA rendezvenyre maga a(z) %d. jelentkezo \n", number);
}

void listazas()
{
	FILE *jelentkezettek;
	
	jelentkezettek = fopen("jelentkezettek.txt","r");
	char kiir[MAX_SIZE];
	printf("\nA rendezvenyre jelentkezettek adatai:\n");
	printf("===========================================================\n\n");
	while(fgets(kiir,100,jelentkezettek) != NULL)
	{
		printf("%s",kiir);
	};
	
	fclose(jelentkezettek);
}

void torles()
{
	char search[MAX_SIZE];
	printf("Addja meg annak a jelentkezonek a nevet, akit torolni szeretne:\t");
	scanf("%s",search);
	
	FILE *jelentkezettek;
	FILE *temp;
	jelentkezettek = fopen("jelentkezettek.txt","r");
	temp = fopen("temp.txt","w");
	char line[MAX_SIZE];
	
	while(fgets(line,sizeof(line),jelentkezettek) != NULL)
	{
		
		char name[MAX_SIZE];
		char mail[MAX_SIZE];
		char id[MAX_SIZE];
		char asctime[MAX_SIZE];
		sscanf(line,"%s %s %s %s",name,mail,id,asctime);
		if( strcmp(name,search) != 0 )
		{
			fputs(line,temp);
		}
	}
	
	fclose(jelentkezettek);
	fclose(temp);
	
	copy_file("temp.txt","jelentkezettek.txt");
}

void modositas()
{
	char search[MAX_SIZE];
	printf("Addja meg annak a jelentkezonek a nevet,\nakit modositani szeretne:\t");
	scanf("%s",search);
	
	FILE *jelentkezettek;
	FILE *temp;
	jelentkezettek = fopen("jelentkezettek.txt","r");
	temp = fopen("temp.txt","w");
	char line[MAX_SIZE];
	
	while(fgets(line,sizeof(line),jelentkezettek) != NULL)
	{
		char name[MAX_SIZE];
		char mail[MAX_SIZE];
		char id[MAX_SIZE];
		char asctime[MAX_SIZE];
		sscanf(line,"%s %s %s %s",name,mail,id,asctime);
		
		char n_name[MAX_SIZE];  // Új név
		char n_mail[MAX_SIZE];  // Új e-mail
		char n_id[MAX_SIZE];  	// Új rendezvényazonosító			
		
		if( strcmp(search,name) == 0 )
		{
			char menu[MAX_SIZE];
			
			printf("Mit szeretne modositani?\n");
			printf("Nev: (1)\n");
			printf("E-mail: (2)\n");
			printf("Rendezveny azonositoja: (3)\n");
			
			scanf("%s",menu);
			
			if( strcmp(menu,"1") == 0 )
			{
				printf("Addja meg az uj nevet:\t");
				scanf("%s",n_name);
				fprintf(temp,"%s %s %s %s\n",n_name,mail,id,asctime);
			}
			else if( strcmp(menu,"2") == 0 )
			{
				printf("Addja meg az uj e-mail cimet:\t");
				scanf("%s",n_mail);
				fprintf(temp,"%s %s %s %s\n",name,n_mail,id,asctime);
			}
			else if( strcmp(menu,"3") == 0 )
			{
				printf("Addja meg az uj rendezveny azonositot:\t");
				scanf("%s",n_id);
				fprintf(temp,"%s %s %s %s\n",name,mail,n_id,asctime);
			}
			else
			{
				modositas();
			}
		}
		else
		{
			fputs(line,temp);
		}
	}
	
	fclose(jelentkezettek);
	fclose(temp);
	
	copy_file("temp.txt","jelentkezettek.txt");	
}

void rendezveny_torlese()
{
	char search[MAX_SIZE];
	printf("Addja meg annak a rendezvenynek az azonositojat,\namit torolni szeretne:\t");
	scanf("%s",search);
	
	FILE *rendezveny;
	FILE *temp;
	rendezveny = fopen("rendezveny.txt","r");
	temp = fopen("temp.txt","w");
	char line[MAX_SIZE];
	
	//rendezvény törlése
	
	while(fgets(line,sizeof(line),rendezveny) != NULL)
	{
		char id[MAX_SIZE]; 	//azonosító
		char title[MAX_SIZE]; 	//rendezvény neve
		sscanf(line,"%s %s",&id,title);
		if( strcmp(id,search) != 0 )
		{
			fputs(line,temp);
		}
	}
	
	fclose(rendezveny);
	fclose(temp);
	
	copy_file_rend("temp.txt","rendezveny.txt");
	
	//rendezvényre jelentkezettek törlése
	
	FILE *jelentkezettek;
	jelentkezettek = fopen("jelentkezettek.txt","r");
	temp = fopen("temp.txt","w");
	
	while(fgets(line,sizeof(line),jelentkezettek) != NULL)
	{
		
		char name[MAX_SIZE];
		char mail[MAX_SIZE];
		char id[MAX_SIZE];
		char asctime[MAX_SIZE];
		sscanf(line,"%s %s %s %s",name,mail,id,asctime);
		if( strcmp(id,search) != 0 )
		{
			fputs(line,temp);
		}
	}
	
	fclose(jelentkezettek);
	fclose(temp);
	
	copy_file("temp.txt","jelentkezettek.txt");
	
}

void copy_file(const char *from,const char *to)
{
	FILE *fr;
	FILE *t;
	fr = fopen(from,"r");
	t = fopen(to,"w");
	
	char line[MAX_SIZE];
	char name[MAX_SIZE];	//jelentkező neve
	char mail[MAX_SIZE];	//jelentkező e-mail címe
	char id[MAX_SIZE];		//rendezveny azonosítója
	char asctime[MAX_SIZE];
	while(fgets(line,sizeof(line),fr) != NULL)
	{
		sscanf(line,"%s %s %s %s",name,mail,id,asctime);
		fprintf(t,"%s %s %s %s\n",name,mail,id,asctime);
	}
	
	fclose(fr);
	fclose(t);
	
	remove("temp.txt");
}

void copy_file_rend(const char *from,const char *to)
{
	FILE *fr;
	FILE *t;
	fr = fopen(from,"r");
	t = fopen(to,"w");
	
	char line[MAX_SIZE];
	char id[MAX_SIZE];	//rendezveny azonosítója
	char title[MAX_SIZE];
	while(fgets(line,sizeof(line),fr) != NULL)
	{
		sscanf(line,"%s %s",id,title);
		fprintf(t,"%s %s\n",id,title);
	}
	
	fclose(fr);
	fclose(t);
	
	remove("temp.txt");
}