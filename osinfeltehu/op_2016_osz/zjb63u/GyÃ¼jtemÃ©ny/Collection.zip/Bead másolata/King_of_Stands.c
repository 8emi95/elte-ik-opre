/*
Egy kiállításokat, rendezvényeket szervező társaság a "King of Stands",
elektronikus látogatói nyilvántartást készített. A látogatók a nyilvántartásba
jelentkezéskor megadják nevüket, mail címüket, a rendezvény azonosító számát!
Az elektronikus rendszer a jelentkezés nyugtázásaként visszaadja,
hogy hányadik vendégként történt meg a regisztráció!
Az alkalmazás adjon lehetőséget vendég jelentkezéshez, a jelentkezettek listázásához,
egy vendég adatainak módosításához, törléséhez. Legyen lehetőségünk egy új rendezvény indításához,
egy rendezvény összes adatának törléséhez! A jelentkezőknél a korábbi adatok mellett
rögzítsük automatikusan a jelentkezési időt(rendszeridő) is(ezt nem kell bekérni)!
Készítsünk C programot, amellyel a leírt tevékenység elvégezhető. Az adatokat fájlban tároljuk.
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define MAX_SIZE 512

void menu();
void rendezveny_inditasa();
void jelentkezes();
void listazas();
void torles();
void modositas();
void rendezveny_torlese();
void copy_file();
void copy_file_rend();

int main(int argc,char *argv[])
{
	menu();
	
	return 0;
}

void menu()
{
	char menup[MAX_SIZE];
	
	while(1)
	{
		printf("===========================================================\n");
		printf("Udvozoljuk a King of stands nyilvantartasaban\n");
		printf("Az alabb felsorolt lehetosegek allnak rendelkezesere:\n");
		printf("Jelentkezes egy rendezvenyre\t(1)\n");
		printf("Rendezvenyek listazasa\t(2)\n");
		printf("Rendezvenyre jelentkezett szemely adatainak modositasa\t(3)\n");
		printf("Rendezvenyre jelentkezett szemely torlese\t(4)\n");
		printf("===========================================================\n");
		printf("Uj rendezveny inditasa\t(5)\n");
		printf("Rendezveny torlese\t(6)\n");
		printf("A nyilvantartas bezarasahoz nyomja meg CTRL + C kombinaciot\n>");
		scanf("%s",menup);
		printf("===========================================================\n");
			
			if( strcmp(menup,"1") == 0 )
			{
				jelentkezes();
			}
			else if( strcmp(menup,"2") == 0 )
			{
				listazas();
			}
			else if( strcmp(menup,"3") == 0 )
			{
				modositas();
			}
			else if( strcmp(menup,"4") == 0 )
			{
				torles();
			}
			else if( strcmp(menup,"5") == 0 )
			{
				rendezveny_inditasa();
			}
			else if( strcmp(menup,"6") == 0 )
			{
				rendezveny_torlese();
			}
			else
			{
				printf("Nem definialt menupont, folytatashoz nyomjon ENTER-t\n>");
				getchar();
				menu();
			}
	}
}

void rendezveny_inditasa()
{
	FILE *rendezveny;
	rendezveny = fopen("rendezveny.txt","a+");
	
	int id;	//azonosító
	char title[MAX_SIZE]; 	//rendezvény neve
	
	printf("Addja meg a rendezveny adatait:");
	printf("\nRendezveny azonositoja:\t");
	scanf("%d",&id);
	printf("\nRendezveny neve:\t");
	scanf("%s",title);
	
	fprintf(rendezveny,"\n%d %s",id,title);
	fclose(rendezveny);
}

void jelentkezes()
{
	FILE *jelentkezettek;
	jelentkezettek = fopen("jelentkezettek.txt","a+");
	
	char name[MAX_SIZE];	//jelentkező neve
	char mail[MAX_SIZE];	//jelentkező e-mail címe
	int id;	//rendezveny azonosítója
	time_t rawtime;
	struct tm * timeinfo;

	
	
	printf("Addja meg az adatait:");
	printf("\nNeve:\t");
	scanf("%s",name);
	printf("\nE-mail cime:\t");
	scanf("%s",mail);
	printf("\nRendezveny azonositoja:\t");
	scanf("%d",&id);
	time ( &rawtime );
	timeinfo = localtime ( &rawtime );
	
	fprintf(jelentkezettek,"\n%s %s %d %s",name,mail,id,asctime (timeinfo));
	fclose(jelentkezettek);
	
	//sorszám kiszámitása
	
	jelentkezettek = fopen("jelentkezettek.txt","r");
	char line[MAX_SIZE];
	int number = 0;
	
	while(fgets(line,sizeof(line),jelentkezettek) != NULL)
	{
		char n_name[MAX_SIZE];  	//  név
		char n_mail[MAX_SIZE];  	//  e-mail
		int n_id;					//  rendezvényazonosító
		char n_asctime[MAX_SIZE];	//  rendszeridő
		sscanf(line,"%s %s %d %s",n_name,n_mail,n_id,n_asctime);
		
		if( strcmp(id,n_id) == 0 )
		{
			number++;
		}
	}
	
	fclose(jelentkezettek);
	
	printf("\nA rendezveny maga a(z) %d. jelentkezo \t", number);
}

void listazas()
{
	FILE *jelentkezettek;
	
	jelentkezettek = fopen("jelentkezettek.txt","r");
	char kiir[MAX_SIZE];
	printf("\nA rendezvenyre jelentkezettek adatai:\n");
	while(fgets(kiir,100,jelentkezettek) != NULL)
	{
		printf("%s",kiir);
	};
	
	fclose(jelentkezettek);
}

void torles()
{
	char search[MAX_SIZE];
	printf("Addja meg annak a jelentkezonek a nevet, akit torolni szeretne:\t");
	scanf("%s",search);
	
	FILE *jelentkezettek;
	FILE *temp;
	jelentkezettek = fopen("jelentkezettek.txt","r");
	temp = fopen("temp.txt","w");
	char line[MAX_SIZE];
	
	while(fgets(line,sizeof(line),jelentkezettek) != NULL)
	{
		
		char name[MAX_SIZE];
		char mail[MAX_SIZE];
		int id;
		char asctime[MAX_SIZE];
		sscanf(line,"%s %s %d %s",name,mail,id,asctime);
		if( strcmp(name,search) != 0 )
		{
			fputs(line,temp);
		}
	}
	
	fclose(jelentkezettek);
	fclose(temp);
	
	copy_file("temp.txt","jelentkezettek.txt");
}

void modositas()
{
	char search[MAX_SIZE];
	printf("Addja meg annak a jelentkezonek a nevet, akit modositani szeretne:\t");
	scanf("%s",search);
	
	FILE *jelentkezettek;
	FILE *temp;
	jelentkezettek = fopen("jelentkezettek.txt","r");
	temp = fopen("temp.txt","w");
	char line[MAX_SIZE];
	
	while(fgets(line,sizeof(line),jelentkezettek) != NULL)
	{
		char name[MAX_SIZE];
		char mail[MAX_SIZE];
		int id;
		char asctime[MAX_SIZE];
		sscanf(line,"%s %s %d %s",name,mail,id,asctime);
		
		char n_name[MAX_SIZE];  // Új név
		char n_mail[MAX_SIZE];  // Új e-mail
		int n_id;				// Új rendezvényazonosító
		
		if( strcmp(search,name) == 0 )
		{
			char menu[MAX_SIZE];
			
			printf("Mit szeretne modositani?\n");
			printf("Nev: (1)\n");
			printf("E-mail: (2)\n");
			printf("Rendezveny azonositoja: (3)\n");
			
			scanf("%s",menu);
			
			if( strcmp(menu,"1") == 0 )
			{
				printf("Addja meg az uj nevet:\t");
				scanf("%d",n_name);
				fprintf(temp,"%s %s %d %s\n",n_name,mail,id,asctime);
			}
			else if( strcmp(menu,"2") == 0 )
			{
				printf("Addja meg az uj e-mail cimet:\t");
				scanf("%s",n_mail);
				fprintf(temp,"%s %s %d %s\n",name,n_mail,id,asctime);
			}
			else if( strcmp(menu,"3") == 0 )
			{
				printf("Addja meg az uj rendezveny azonositot:\t");
				scanf("%d",&n_id);
				fprintf(temp,"%s %s %d %s\n",name,mail,n_id,asctime);
			}
			else
			{
				modositas();
			}
		}
		else
		{
			fputs(line,temp);
		}
	}
	
	fclose(jelentkezettek);
	fclose(temp);
	
	copy_file("temp.txt","jelentkezettek.txt");	
}

void rendezveny_torlese()
{
	char search[MAX_SIZE];
	printf("Addja meg annak a rendezvenynek az azonositojat, amit torolni szeretne:\t");
	scanf("%s",search);
	
	FILE *rendezveny;
	FILE *temp;
	rendezveny = fopen("rendezveny.txt","r");
	temp = fopen("temp.txt","w");
	char line[MAX_SIZE];
	
	//rendezvény törlése
	
	while(fgets(line,sizeof(line),rendezveny) != NULL)
	{
		
		int id;					//azonosító
		char title[MAX_SIZE]; 	//rendezvény neve
		sscanf(line,"%d %s",id,title);
		if( strcmp(id,search) != 0 )
		{
			fputs(line,temp);
		}
	}
	
	fclose(rendezveny);
	fclose(temp);
	
	copy_file_rend("temp.txt","rendezveny.txt");
	
	//rendezvényre jelentkezettek törlése
	
	FILE *jelentkezettek;
	jelentkezettek = fopen("jelentkezettek.txt","r");
	temp = fopen("temp.txt","w");
	char line[MAX_SIZE];
	
	while(fgets(line,sizeof(line),jelentkezettek) != NULL)
	{
		
		char name[MAX_SIZE];
		char mail[MAX_SIZE];
		int id;
		char asctime[MAX_SIZE];
		sscanf(line,"%s %s %d %s",name,mail,id,asctime);
		if( strcmp(id,search) != 0 )
		{
			fputs(line,temp);
		}
	}
	
	fclose(jelentkezettek);
	fclose(temp);
	
	copy_file("temp.txt","jelentkezettek.txt");
	
}

void copy_file(const char *from,const char *to)
{
	FILE *fr;
	FILE *t;
	fr = fopen(from,"r");
	t = fopen(to,"w");
	
	char line[MAX_SIZE];
	char name[MAX_SIZE];	//jelentkező neve
	char mail[MAX_SIZE];	//jelentkező e-mail címe
	int id;	//rendezveny azonosítója
	char asctime[MAX_SIZE];
	while(fgets(line,sizeof(line),fr) != NULL)
	{
		sscanf(line,"%s %s %d %s",name,mail,&id,asctime);
		fprintf(t,"%s %s %d %s\n",name,mail,id,asctime);
	}
	
	fclose(fr);
	fclose(t);
	
	remove("temp.txt");
}

void copy_file_rend(const char *from,const char *to)
{
	FILE *fr;
	FILE *t;
	fr = fopen(from,"r");
	t = fopen(to,"w");
	
	char line[MAX_SIZE];
	int id;	//rendezveny azonosítója
	char title[MAX_SIZE];
	while(fgets(line,sizeof(line),fr) != NULL)
	{
		sscanf(line,"%d %s",&id,title);
		fprintf(t,"%d %s\n",id,title);
	}
	
	fclose(fr);
	fclose(t);
	
	remove("temp.txt");
}