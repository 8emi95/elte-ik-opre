#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h> //open,create
#include <sys/types.h> //open
#include <unistd.h>  //fork
#include <signal.h>
#include <sys/stat.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>

char * fname ="events.txt";


char *trim (char *s) {
    int i = strlen(s)-1;
    if ((i > 0) && (s[i] == '\n'))
        s[i] = '\0';
    return s;
}

int length(char * str)
{
    int l=0;
    while (*str++!=0)l++; //*str points to the next character
    return l;
}

int doesFileExist(const char *filename) {
    struct stat st;
    int result = stat(filename, &st);
    return result == 0;
}

void arrivalAction(int signumber){
    printf("I have arrived, ready to host the event! (Partner)\n");
}

void organise_event(char location[])
{
    printf("At %s, waiting for guests!",location);
}

int main()
{
    srand(time(NULL));

    printf("\n******************\nListing registered guests\n*****************\n");
    FILE * f;
    f=fopen(fname,"r");
    if (f==NULL){perror("File opening error\n"); exit(1);}

    char guestName[20];
    int guestNumber;
    char temp_string[20];

    struct guestname{
        char name[30];
    };

    int succ;
    char guestNameParent[20];
    int numberOfGuests;
    char numberofGuestsChar[20];
    int siker;
    int i=0;


    struct sigaction partnerArrive;
    partnerArrive.sa_handler = arrivalAction;
    sigemptyset(&partnerArrive.sa_mask);
    partnerArrive.sa_flags = 0;
    sigaction(SIGUSR1,&partnerArrive,NULL);

    pid_t child_pid;
    pid_t pid = getpid();  // char array for reading from pipe


    while (!feof(f)){

        int pipefd[2];
        int backpipefd[2];


        if (pipe(pipefd) == -1)
        {
            perror("Hiba a pipe nyitaskor!");
            exit(EXIT_FAILURE);
        }

        if (pipe(backpipefd) == -1)
        {
            perror("Hiba a pipe nyitaskor!");
            exit(EXIT_FAILURE);
        }
        child_pid = fork();	// creating parent-child processes
        if (child_pid == -1)
        {
            perror("Fork hiba");
            exit(EXIT_FAILURE);
        }
        // child process
        if (child_pid == 0 && pid > 0)
        {
            close(pipefd[1]);  //Usually we close the unused write end
            close(backpipefd[0]);
            read(pipefd[0], &guestNumber, sizeof(int));
            read(pipefd[0],temp_string,sizeof(temp_string)); // reading max 100 chars
            sleep(5);

            kill(getppid(),SIGUSR1);

            sleep(2);
            printf("I'm waiting for the following guests: (Partner)\n");

            struct guestname* list;
            list = (struct guestname*) malloc(guestNumber*sizeof(struct guestname));
            for (i=0;i<guestNumber;i++){
                read(pipefd[0], &list[i], sizeof(struct guestname));
                printf("%s",list[i].name);
            }
            close(pipefd[0]); // finally we close the used read end

            printf("I am hosting the event (Partner).\n");
            printf("The event has come to its end (Partner).\n");


            //calculating how successful the event was
            siker = rand()%100;
            printf("sending success:%i.\n",siker);
            write(backpipefd[1], &siker, sizeof(int));



            for (i=0;i<guestNumber;i++){
                int arrived =rand()%10;
                if ( arrived!= 0){
                    write(backpipefd[1], &list[i], sizeof(struct guestname));
                }
            }

            close(backpipefd[1]);

            free(list);
        }
        else
        {   // szulo process
            printf("Parent starts!\n");
            close(pipefd[0]); //Usually we close unused read end
            close(backpipefd[1]); //Usually we close unused read end

            fgets(numberofGuestsChar,20,f);
            numberOfGuests = atoi(numberofGuestsChar);
            write(pipefd[1], &numberOfGuests,sizeof(int));

            char currentEvent[20];
            fgets(currentEvent,20,f); //INT_MAX=+2147483647
            write(pipefd[1], currentEvent,sizeof(currentEvent));

            sigset_t sigset;
            sigfillset(&sigset);
            sigdelset(&sigset,SIGUSR1);
            sigdelset(&sigset,SIGINT);
            sigsuspend(&sigset);

            char currentGuest[20];
            struct guestname guest;
            int i;
            for(i=0; i<numberOfGuests; ++i)
            {
                fgets(guest.name,20,f);
                write(pipefd[1], &guest, sizeof(struct guestname));
            }
            close(pipefd[1]);
            sleep(5);

            printf("Parent has written into the pipe!\n");

            read(backpipefd[0], &succ, sizeof(int));
            printf("The event was %d%% successful.\n", succ);

            printf("These guests showed up:\n");
            while (read(backpipefd[0], &guest,sizeof(struct guestname)) > 0){
                printf("%s", guest.name);
            };
            close(backpipefd[0]);
            int status;
            wait(&status);
        }
        exit(EXIT_SUCCESS);	// force exit, not necessary
    }
    if (pid > 0){
        fclose(f);
    }
    return 0;
}