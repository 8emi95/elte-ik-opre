#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h> //open,creat
#include <sys/types.h> //open
#include <sys/stat.h>
#include <string.h>
#include <time.h>

int number_of_guests = 0;
char * fname ="data.txt";
char * ename ="event.txt";
char * gname ="tmp.txt";

int doesFileExist(const char *filename) {
    struct stat st;
    int result = stat(filename, &st);
    return result == 0;
}

void use_fopen_text(char* fname){
 printf("\n******************\nListing registered guests\n*****************\n");
 FILE * f;
 f=fopen(fname,"r");
 if (f==NULL){perror("File opening error\n"); exit(1);}
 char line[160];
 while (!feof(f)){
   fgets(line,sizeof(line),f);
   printf("%s",line);
 } 
 printf("\n");
 fclose(f);
}

void modify_fopen_text(char* fname,char * guest, int modify, char * newdata){
 FILE *f;
 FILE *g;
 f=fopen(fname,"r");
 g=fopen(gname,"w");
 int found =0;
 if (f==NULL){perror("File opening error\n"); exit(1);}
    char line[160];
    while (!feof(f)){
        fgets(line,sizeof(line),f);
        
        //we found the right line:
        if(strstr(line, guest) != NULL) {
            if(modify!=2)
            {
                int whitespace =0;
                int i;          
                for (i = 0; i < strlen(guest); i++){
                    if(guest[i] == ' ') {
                        ++whitespace;
                    }
                }  
                
                //0 if email, 1 if id, add this value
                int temp = 0;
                char * pch;
                pch = strtok(line," ");
                while (pch != NULL)
                {
                    //writing back everything
                    if(temp==whitespace+modify+1)
                    {
                        fprintf(g, newdata);
                        fprintf(g, " ");
                    }
                    else //except the data to be modified
                    {
                        fprintf(g, pch);
                        fprintf(g, " ");
                    }
                    pch = strtok (NULL, " ");
                    temp++;
                }
            }
        }
        else
        {
            fprintf(g, line);
        }
    } 
    printf("\n");
    fclose(f);
    fclose(g);
    rename(fname,"tempname.txt");
    rename(gname,fname);
    rename("tempname.txt",gname);
    remove(gname);
}

void write_to_file(char* fname, char* text){
    FILE *fp;
    if(1==doesFileExist(fname))
    {
        fp=fopen(fname, "a+");
        if (fp==NULL){perror("File opening error\n"); exit(1);}
            char c; //instead of char, you can use any other type, struct as well
        
        fprintf(fp, text);
    }
    else
    {
        fp=fopen(fname, "w");
        if (fp==NULL){perror("File opening error\n"); exit(1);}
            char c; //instead of char, you can use any other type, struct as well
        
        fprintf(fp, text);
    }
    
    fclose(fp);
}

void print_main_menu(){
    printf("Please choose from the following options:\n");
    printf("1 - Register a guest\n");
    printf("2 - List registered guests\n");
    printf("3 - Modify data of a guest\n");
    printf("4 - Delete data of a guest\n");
    printf("5 - Create a new event\n");
    printf("6 - Delete data of an event\n");
    printf("7 - Exit\n");
}

void register_guest(){
    char *guest_name = malloc (100);
    printf("Please enter your name:\n");
    scanf (" %[^\n]%*c", guest_name);
    
    char guest_email[100];
    printf("Please enter your email address:\n");
    scanf ("%s", guest_email);
    
    char event_id[100];
    printf("Please enter the event id:\n");
    scanf ("%s", event_id);
    
    
    time_t rawtime;
    struct tm * timeinfo;

    time ( &rawtime );
    timeinfo = localtime ( &rawtime );
    
    write_to_file(fname,guest_name);
    write_to_file(fname," ");
    write_to_file(fname,guest_email);
    write_to_file(fname," ");
    write_to_file(fname,event_id);
    write_to_file(fname," ");
    write_to_file(fname,asctime (timeinfo));
    write_to_file(fname,"\n");
    
    number_of_guests++;
    printf("You have been registered as the %d. guest!\n",number_of_guests);
}

void list_guests(){
    use_fopen_text(fname);
}

void modify_data(){
    int value=0;
    
    char *guest_name = malloc (100);
    printf("Please enter the name for which you would like to modify data:\n");
    scanf (" %[^\n]%*c", guest_name);
    
    while (value != 1 && value!=2){
        printf("Please choose from the data type you would like to modify:\n");
        printf("1 - Email\n");
        printf("2 - Event ID\n");
        scanf ("%d",&value);
    }
    
    char *new_data = malloc (100);
    printf("Please enter the new data you would like to replace the old one with:\n");
    scanf (" %[^\n]%*c", new_data);
            
    modify_fopen_text(fname, guest_name, value-1,new_data);
}

void delete_guest(){
    char *guest_name = malloc (100);
    printf("Please enter the name for which you would like delete the registration:\n");
    scanf (" %[^\n]%*c", guest_name);
    
    modify_fopen_text(fname, guest_name, 2,"");
}

void new_event(){
    char *event_name = malloc (100);
    printf("Please enter the name of the event you would like to create:\n");
    scanf (" %[^\n]%*c", event_name);
    
    char event_id[100];
    printf("Please enter the event id:\n");
    scanf ("%s", event_id);
    
    write_to_file(ename,event_name);
    write_to_file(ename," ");
    write_to_file(ename,event_id);
    write_to_file(ename,"\n");
}

void delete_event(){
    char *event_name = malloc (100);
    printf("Please enter the name of the event which you would like to delete:\n");
    scanf (" %[^\n]%*c", event_name);
    
    modify_fopen_text(ename, event_name, 2,"");
}

void main_menu(){
    int value=0;
    while (value != 7){
       print_main_menu();
       scanf ("%d",&value);
       switch(value) {

        case 1  :
            register_guest();
            break; 
            
        case 2  :
            list_guests();
            break; 
        
        case 3  :
            modify_data();
        break; 
        
        case 4  :
            delete_guest();
        break; 
        case 5  :
            new_event();
        break; 
        
        case 6  :
            delete_event();
        break;
        }
    }
}

//cd C:\Users\Toncsi\Documents\IK\otodik_felev\Oprendszerek
//gcc 1_bead.c –o 1_bead


int main()
{    
    main_menu();
    
	return 0;
}


/*
void use_fopen_bin(char* fname){
    printf("\n******************\nUsing fopen -  binary \n*****************\n");
    FILE * f;
    f=fopen(fname,"rb");
    if (f==NULL){perror("File opening error\n"); exit(1);}
        char c; //instead of char, you can use any other type, struct as well
    while (!feof(f)){
       fread(&c,sizeof(c),sizeof(c),f); //use fwrite for writing
       printf("%c",c);
    } 
        printf("\n");
        fseek(f,0,SEEK_SET); //position to the first character, SEEK_SET,SEEK_CUR,SEEK_END
        fread(&c,sizeof(c),sizeof(c),f);
        printf("First character - after positioning %c\n",c);
    
    fclose(f);
}
*/

