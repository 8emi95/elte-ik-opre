package generator;

public class InvalidElementException extends Exception {

	private static final long serialVersionUID = -6713207950001237437L;

	public InvalidElementException(String message) {
		super(message);
	}

}
