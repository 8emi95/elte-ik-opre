package generator;

import java.util.ArrayList;
import java.util.List;

public class AsciiSequenceGenerator implements SequenceGenerator<Character> {

	private static final int ALPHABET_SIZE = 26;

	@Override
	public List<Character> generate(Character element, int n, int distance) throws InvalidElementException {
		if (!isLetter(element) || distance < 0 || n < 0) {
			throw new InvalidElementException("The given parameters are not valid.");
		}

		List<Character> result = new ArrayList<>();
		if (n > 0) {
			fillSequenceList(element, n, distance, result);
		}

		return result;
	}

	private boolean isLetter(Character element) {
		return element != null && ((element >= 65 && element <= 90) || (element >= 97 && element <= 122));
	}

	private void fillSequenceList(Character element, int n, int distance, List<Character> result) {
		result.add(element);
		while (n > 1) {
			element = (char) (element + distance);
			if (element > 122 || element > 90 && element < 97) {
				element = (char) (element - ALPHABET_SIZE);
			}
			result.add(element);
			n--;
		}
	}

}
