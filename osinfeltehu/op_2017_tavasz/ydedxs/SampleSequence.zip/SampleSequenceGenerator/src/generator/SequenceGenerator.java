package generator;

import java.util.List;

@FunctionalInterface
// functional interfaces are interfaces, that have exactly 1 abstract function
// they are good to write lambda functions
public interface SequenceGenerator<T> {

	public List<T> generate(T element, int n, int d) throws InvalidElementException;

}
