package generator;

import java.util.ArrayList;
import java.util.List;

public class GeometricSequenceGenerator implements SequenceGenerator<Integer> {

	@Override
	public List<Integer> generate(Integer element, int n, int q) throws InvalidElementException {
		if (element == null || n < 0) {
			throw new InvalidElementException("The given parameters are not valid.");
		}

		List<Integer> result = new ArrayList<>();
		if (n > 0) {
			fillSequenceList(element, n, q, result);
		}

		return result;
	}

	private void fillSequenceList(Integer element, int n, int q, List<Integer> result) {
		result.add(element);
		while (n > 1) {
			element *= q;
			result.add(element);
			n--;
		}
	}

}
