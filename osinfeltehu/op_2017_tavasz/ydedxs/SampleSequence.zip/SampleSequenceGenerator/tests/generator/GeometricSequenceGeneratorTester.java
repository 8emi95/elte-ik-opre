package generator;

import java.util.Arrays;
import java.util.Collections;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class GeometricSequenceGeneratorTester {

	private GeometricSequenceGenerator gen;

	@Before
	public void setup() {
		gen = new GeometricSequenceGenerator();
	}

	@Test(expected = InvalidElementException.class)
	public void nullElement() throws Exception {
		gen.generate(null, 4, 2);
	}

	@Test(expected = InvalidElementException.class)
	public void wrongLength() throws Exception {
		gen.generate(3, -2, 2);
	}

	@Test
	public void zeroLength() throws Exception {
		Assert.assertEquals(Collections.EMPTY_LIST, gen.generate(3, 0, 5));
	}

	@Test
	public void simpleSequence() throws Exception {
		Assert.assertEquals(Arrays.asList(3, 15, 75), gen.generate(3, 3, 5));
	}

	@Test
	public void zeroQ() throws Exception {
		Assert.assertEquals(Arrays.asList(3, 0, 0), gen.generate(3, 3, 0));
	}

	@Test
	public void negativeQ() throws Exception {
		Assert.assertEquals(Arrays.asList(30, -60, 120, -240), gen.generate(30, 4, -2));
	}

}
