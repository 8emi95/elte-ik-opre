package generator;

import java.util.Arrays;
import java.util.Collections;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class AsciiSequenceGeneratorTester {

	private AsciiSequenceGenerator gen;

	@Before
	public void setup() {
		gen = new AsciiSequenceGenerator();
	}

	@Test(expected = InvalidElementException.class)
	public void nullElement() throws Exception {
		gen.generate(null, 5, 3);
	}

	@Test(expected = InvalidElementException.class)
	public void wrongElement() throws Exception {
		gen.generate('3', 5, 3);
	}

	@Test(expected = InvalidElementException.class)
	public void wrongCounter() throws Exception {
		gen.generate('a', -1, 3);
	}

	@Test(expected = InvalidElementException.class)
	public void wrongDistance() throws Exception {
		gen.generate('c', 5, -3);
	}

	@Test
	public void emptySequence() throws Exception {
		Assert.assertEquals(Collections.EMPTY_LIST, gen.generate('a', 0, 3));
	}
	
	@Test
	public void repeated() throws Exception {
		Assert.assertEquals(Arrays.asList('a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a'), gen.generate('a', 10, 0));
	}

	@Test
	public void simpleLowerSequence() throws Exception {
		Assert.assertEquals(Arrays.asList('a', 'd', 'g', 'j', 'm'), gen.generate('a', 5, 3));
	}

	@Test
	public void simpleUpperSequence() throws Exception {
		Assert.assertEquals(Arrays.asList('D'), gen.generate('D', 1, 5));
	}

	@Test
	public void restartingSequence() throws Exception {
		Assert.assertEquals(Arrays.asList('Y', 'D', 'I', 'N'), gen.generate('Y', 4, 5));
	}
	
	@Test
	public void restartingSequence2() throws Exception {
		Assert.assertEquals(Arrays.asList('z', 'a', 'b', 'c'), gen.generate('z', 4, 1));
	}

}
