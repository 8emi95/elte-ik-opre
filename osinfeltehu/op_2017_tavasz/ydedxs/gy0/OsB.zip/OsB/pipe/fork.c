#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  //fork
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h> //waitpid
#include <errno.h>


int main()
{
 signal(SIGTERM,SIG_IGN); //handler = SIG_IGN - ignore the signal (not SIGKILL,SIGSTOP),
                           //handler = SIG_DFL - back to default behavior

 //1
 int status,fd;
 int notacommonvalue=1;
 //printf("The value is %i before forking \n",notacommonvalue);

 //2
 unlink("fifo1.ftc");
 unlink("fifo2.ftc");
 int fid1=mkfifo("fifo1.ftc", S_IRUSR|S_IWUSR ); // creating named pipe file
 int fid2=mkfifo("fifo2.ftc", S_IRUSR|S_IWUSR ); // creating named pipe file
 if (fid1==-1||fid2==-1)
    {
	printf("Error number: %i",errno);
	//exit(EXIT_FAILURE);
	//unlink("fifo1.ftc");
	//unlink("fifo2.ftc");
    }

 pid_t  pid=fork(); //forks make a copy of variables


 if (pid<0){perror("The fork calling was not succesful\n"); exit(1);}


 if (pid>0) //the parent process, it can see the returning value of fork - the child variable!
 {
    char s[1024]="nothing";
    printf("parent process:start \n");

    //pause();
    //read
    printf("parent process:reading \n");
    fd=open("fifo1.ftc",O_RDONLY);
    read(fd,s,sizeof(s));
    printf("parent process: read a : %s \n",s);
    close(fd);
    //write
     printf("parent process:writing \n");
    fd=open("fifo2.ftc",O_WRONLY);
    write(fd,"how are you \n",12);
    printf("parent process:writed\n");
    close(fd);



    //pause();
    ////pid_t childPid = wait(&status);
    //waits the end of child process PID number=child, the returning value will be in status
    //0 means, it really waits for the end of child process - the same as wait(&status)
    //printf("parent process:The value is %i in parent process (remain the original) \n",notacommonvalue);
    ////int childReturn = WEXITSTATUS(status);
    ////printf("the child return value is %d \n",childReturn);
    //printf("parent process:child pid is : %i \n",pid);

    //write


    //read

    unlink("fifo1.ftc");
    printf("parent process:end \n");


 }


 else if (pid == 0)//child process
 {
    char s[1024]="nothing";
    printf("child process: start  \n");
    //kill(getppid(),SIGTERM);
    //printf("child process: parent pid is :%i my pid is :%i \n",getppid(),getpid());
    notacommonvalue=5; //it changes the value of the copy of the variable
    //printf("child process: The value is %i in child process \n",notacommonvalue);

    //write
    printf("child process: writing  \n");
    fd=open("fifo1.ftc",O_WRONLY);
    write(fd,"helllllo\n",12);
    printf("child process: writed  \n");
    close(fd);
    //read
    printf("child process: reading  \n");
    fd=open("fifo2.ftc",O_RDONLY);
    read(fd,s,sizeof(s));
    printf("child process: read a : %s \n",s);
    close(fd);
    unlink("fifo2.ftc");

    //kill(getppid(),SIGTERM);
    printf("child process: end \n");
 }
 return 0;
}
