#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>  //fork
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>//O_RDONLY,
#include <sys/wait.h> //waitpid
#include <errno.h>
#include <poll.h> // poll
#include <unistd.h> //close
#include <sys/time.h> //rand


int main()
{
 signal(SIGTERM,SIG_IGN); //handler = SIG_IGN - ignore the signal (not SIGKILL,SIGSTOP),
                           //handler = SIG_DFL - back to default behavior

 //1
 int status,f1,f2;
 int notacommonvalue=1;
 //printf("The value is %i before forking \n",notacommonvalue);

 //2
 unlink("fifo1.ftc");
 unlink("fifo2.ftc");
 int fid1=mkfifo("fifo1.ftc", S_IRUSR|S_IWUSR ); // creating named pipe file
 int fid2=mkfifo("fifo2.ftc", S_IRUSR|S_IWUSR ); // creating named pipe file
 if (fid1==-1||fid2==-1)
    {
	printf("Error number: %i",errno);
	//exit(EXIT_FAILURE);
	//unlink("fifo1.ftc");
	//unlink("fifo2.ftc");
    }
	
 //3
 struct pollfd poll_fds1[5];// poll file descriptor array
 f1=open("fifo1.ftc",O_RDWR);
 poll_fds1[0].fd=f1; 	// file decriptor
 poll_fds1[0].events=POLLIN;//|POLLOUT; //watch for  reading, writing
  struct pollfd poll_fds2[5];
 f2=open("fifo2.ftc",O_RDWR);
 poll_fds2[0].fd=f2; 	
 poll_fds2[0].events=POLLIN;
 
 pid_t  pid=fork(); //forks make a copy of variables


 if (pid<0){perror("The fork calling was not succesful\n"); exit(1);}


 if (pid>0) //the parent process, it can see the returning value of fork - the child variable!
 {
    char s[1024]="nothing";
    printf("parent process:start \n");

    //pause();
	
    //read
	int result=poll(poll_fds1,1,8000); //
    if (result>0) 
    { 
     printf("The poll revents field is: %i\n",poll_fds1[0].revents);
     if (poll_fds1[0].revents & POLLIN) // POLLIN event occured
     {
	     printf("The poll revents field is: %i\n",poll_fds1[0].revents);
	     if (poll_fds1[0].revents & POLLIN) // POLLIN event occured
	     {
    	 printf("parent process:reading \n");
    	 read(f1,s,sizeof(s));
    	 printf("parent process: read a : %s \n",s);
 		 } 
	 }
 	}
    //write
    printf("parent process:writing \n");
    write(f2,"how are you \n",12);
    printf("parent process:writed\n");



    //pause();
    ////pid_t childPid = wait(&status);
    //waits the end of child process PID number=child, the returning value will be in status
    //0 means, it really waits for the end of child process - the same as wait(&status)
    //printf("parent process:The value is %i in parent process (remain the original) \n",notacommonvalue);
    ////int childReturn = WEXITSTATUS(status);
    ////printf("the child return value is %d \n",childReturn);
    //printf("parent process:child pid is : %i \n",pid);

    //write


    //read


    printf("parent process:end \n");


 }


 else if (pid == 0)//child process
 {
    char s[1024]="nothing";
    printf("child process: start  \n");
    //kill(getppid(),SIGTERM);
    //printf("child process: parent pid is :%i my pid is :%i \n",getppid(),getpid());
    notacommonvalue=5; //it changes the value of the copy of the variable
    //printf("child process: The value is %i in child process \n",notacommonvalue);

    //write
    printf("child process: writing  \n");
    write(f1,"helllllo\n",12);
    printf("child process: writed  \n");
   
    //read
	int result=poll(poll_fds2,1,8000); //
    if (result>0) 
    { 
     printf("The poll revents field is: %i\n",poll_fds2[0].revents);
     if (poll_fds2[0].revents & POLLIN) // POLLIN event occured
     {
	     printf("The poll revents field is: %i\n",poll_fds2[0].revents);
	     if (poll_fds2[0].revents & POLLIN) // POLLIN event occured
	     {
	
    	 printf("child process: reading  \n");
    	 read(f2,s,sizeof(s));
    	 printf("child process: read a : %s \n",s);
 		 } 
	  }
  	 }

    //kill(getppid(),SIGTERM);
    printf("child process: end \n");
 }
     unlink("fifo1.ftc");
	 unlink("fifo2.ftc");
 return 0;
}
