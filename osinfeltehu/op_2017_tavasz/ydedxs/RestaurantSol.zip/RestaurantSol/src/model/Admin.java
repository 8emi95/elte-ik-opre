package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class Admin extends User {

    public Admin() {
        super();
    }

    public Admin(String name, byte[] password, byte[] salt) {
        super(name, password, salt);
        cancelledReservations = new HashSet<>();
    }

    public void cancelRegistration(Reservation reservation) {
        cancelledReservations.add(reservation);
    }

    public Set<Reservation> getCancelledReservations() {
        return cancelledReservations;
    }

    @OneToMany(mappedBy = "cancelledBy", cascade = CascadeType.ALL)
    private Set<Reservation> cancelledReservations;

    @Override
    public boolean isRemoved() {
        return false;
    }


}
