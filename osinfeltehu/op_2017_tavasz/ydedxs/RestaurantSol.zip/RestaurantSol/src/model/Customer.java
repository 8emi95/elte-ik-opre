package model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Customer extends User {
    public Customer() {
        super();
    }

    public Customer(String name, byte[] password, byte[] salt) {
        super(name, password, salt);
        reservations = new HashSet<>();
    }

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private Set<Reservation> reservations;

    @ManyToOne
    private Admin removedBy;

    public void addReservation(Reservation reservation) {
        int count = 0;
        for (Reservation res : reservations) {
            if (!res.isCancelled()) {
                count++;
            }
        }

        if (count < 5) {
            reservations.add(reservation);
        }
    }

    public Set<Reservation> getReservations() {
        return reservations;
    }

    public Admin getRemovedBy() {
        return removedBy;
    }

    public void setRemovedBy(Admin removedBy) {
        this.removedBy = removedBy;
    }

    @Override
    public boolean isRemoved() {
        return removedBy != null;
    }


}
