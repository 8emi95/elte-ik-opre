package model;

import javax.persistence.Entity;

@Entity
public class PriorityReservation extends Reservation {

    public PriorityReservation() {
        super();
    }

}
