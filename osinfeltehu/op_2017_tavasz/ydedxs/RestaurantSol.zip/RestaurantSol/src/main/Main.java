package main;

import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.Admin;
import model.Customer;
import model.Reservation;

public class Main {
    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeySpecException {
        EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("Restaurant");
        EntityManager entityManager = emfactory.createEntityManager();




        // --------------- GRADE 2 ---------------
        // For Grade 2 you need to implement 3 classes in the model: User, Customer and Admin with
        // proper inheritance and the authenticate method from Authentication.java
        Authentication auth = new Authentication(entityManager);

        entityManager.getTransaction().begin();
        Customer tamas = new Customer();
        tamas.setName("Tamas");
        auth.register(tamas, "1234".toCharArray());
        entityManager.persist(tamas);

        Admin istvan = new Admin();
        istvan.setName("Istvan");
        auth.register(istvan, "asdf".toCharArray());
        entityManager.persist(istvan);

        entityManager.getTransaction().commit();

        if (auth.authenticate("Istvan", "asdf".toCharArray()) &&
                !auth.authenticate("Istvan", "456".toCharArray()) &&
                auth.authenticate("Tamas", "1234".toCharArray()) &&
                !auth.authenticate("Tamas", "hadf".toCharArray())) {
            System.out.println("Congrats! You reached grade 2!");
        } else {
            throw new IllegalStateException("Conditions for grade 2 were not met.");
        }





        // --------------- GRADE 3 ---------------
        entityManager.getTransaction().begin();
        Reservation res1 = new Reservation();

        tamas.addReservation(res1);
        res1.setCustomer(tamas);
//        entityManager.persist(res1);
        entityManager.getTransaction().commit();

        List<Customer> customers = entityManager
            .createQuery("SELECT c FROM Customer c WHERE c.name = :name", Customer.class)
            .setParameter("name", "Tamas")
            .getResultList();

        if (customers.size() == 1 &&
                customers.get(0).getReservations().size() == 1 &&
                customers.get(0).getReservations().iterator().next().getId() == res1.getId()) {
            System.out.println("Congrats! You reached grade 3!");
        } else {
            System.out.println("customers.size():" + customers.size());
            System.out.println("customers.get(0).getReservations().size(): " +
                    customers.get(0).getReservations().size());
            System.out.println("customers.get(0).getReservations().iterator().next().getId(): " +
                    customers.get(0).getReservations().iterator().next().getId());
            throw new IllegalStateException("Conditions for grade 3 were not met.");
        }





        // --------------- GRADE 4 ---------------
        entityManager.getTransaction().begin();
        Reservation[] additionalRes = new Reservation[5];
        for (int i = 0; i < 5; i++) {
            additionalRes[i] = new Reservation();
            additionalRes[i].setCustomer(tamas);
//            entityManager.persist(additionalRes[i]);
            tamas.addReservation(additionalRes[i]);
        }
        entityManager.getTransaction().commit();

        List<Customer> customers2 = entityManager
                .createQuery("SELECT c FROM Customer c WHERE c.name = :name", Customer.class)
                .setParameter("name", "Tamas")
                .getResultList();

        if (customers2.size() > 1) {
            System.out.println("customers2.size():" + customers2.size());
            throw new IllegalStateException("Conditions for grade 4 were not met.");
        }

        Customer c = customers2.get(0);
        Set<Integer> ids =
                c.getReservations().stream().map(x -> x.getId()).collect(Collectors.toSet());

        for (int i = 0; i < 4; i++) {
            if (!ids.contains(additionalRes[i].getId())) {
                System.out.println("ids:" + ids + " should contain " + additionalRes[i].getId());
                throw new IllegalStateException("Conditions for grade 4 were not met.");
            }
        }
        if (!ids.contains(additionalRes[4].getId()) && ids.contains(res1.getId())) {
            System.out.println("Congrats! You reached grade 4!");
        } else {
            System.out.println("ids:" + ids + " should not contain " + additionalRes[4].getId());
            System.out.println("ids:" + ids + " should contain " + res1.getId());
            throw new IllegalStateException("Conditions for grade 4 were not met.");
        }





        // --------------- GRADE 5 ---------------
        // Admins can remove Customers. In this case the customer still stays in the database
        // but won't be able to log in anymore.

        entityManager.getTransaction().begin();
        tamas.setRemovedBy(istvan);
        entityManager.getTransaction().commit();

        List<Customer> grade5customers = entityManager
                .createQuery("SELECT c FROM Customer c WHERE c.name = :name", Customer.class)
                .setParameter("name", "Tamas")
                .getResultList();

        if (grade5customers.size() != 1) {
            System.out.println("grade5customers.size(): " + grade5customers.size());
            throw new IllegalStateException("Conditions for grade 5 were not met.");
        }

        if (grade5customers.get(0).isRemoved() &&
                !auth.authenticate("Tamas", "1234".toCharArray())) {
            System.out.println("Congrats! You reached grade 5!");
        } else {
            System.out.println("grade5customers.get(0).isRemoved(): " +
                    grade5customers.get(0).isRemoved());
            System.out.println("auth.authenticate(\"Tamas\", \"1234\".toCharArray()): " +
                    auth.authenticate("Tamas", "1234".toCharArray()));
            throw new IllegalStateException("Conditions for grade 5 were not met.");
        }
    }
}
