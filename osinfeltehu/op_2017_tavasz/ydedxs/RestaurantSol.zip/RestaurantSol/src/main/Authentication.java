package main;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import model.User;

public class Authentication {
    private EntityManager em;

    private final SecureRandom rand;

    private boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a.length != b.length) {
            return false;
        }

        int result = 0;
        for (int i = 0; i < a.length; i++) {
            result |= a[i] ^ b[i];
        }

        return result == 0;
    }

    public Authentication(EntityManager em) {
        super();
        this.em = em;
        this.rand = new SecureRandom();
    }

    public boolean authenticate(String username, char[] password)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        Query query = em.createQuery("SELECT u FROM User u WHERE u.name = :username").setParameter("username", username)
                .setMaxResults(1);

        User u = (User) query.getSingleResult();
        if (u.isRemoved()) return false;

        byte[] hash = hashPassword(password, u.getSalt());
        return constantTimeEquals(hash, u.getPassword());
    }

    public User register(User user, char[] password) throws NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] salt = new byte[256];
        rand.nextBytes(salt);
        ;

        byte[] hash = hashPassword(password, salt);

        user.setPassword(hash);
        user.setSalt(salt);

        return user;
    }

    public byte[] hashPassword(char[] password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeySpecException {
        int iterations = 2000;

        PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, 256);
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        return skf.generateSecret(spec).getEncoded();
    }
}
