#ifndef KERDESSOR_H
#define KERDESSOR_H

void create_kerdessor();
void edit_kerdessor();
void listaz_kerdessor();
void veglegesit_kerdessor();

#endif /* KERDESSOR_H */

