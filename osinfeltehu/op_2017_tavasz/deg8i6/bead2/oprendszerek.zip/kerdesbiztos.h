#ifndef KERDESBIZTOS_H
#define KERDESBIZTOS_H

int biztosKuld();

#endif

