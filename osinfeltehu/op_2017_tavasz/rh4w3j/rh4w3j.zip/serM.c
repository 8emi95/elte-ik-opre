#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <netinet/in.h>




struct par
{
	char nev[256];
	int db;
};

void kiir(struct par stu[])
{
	FILE *fptr;
	 if ((fptr = fopen("program.bin","wb")) == NULL){
       printf("Error! opening file");

       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   int i;
   for(i = 0; i < 10; i++)
   {

      fwrite(&stu[i], sizeof(struct par), 1, fptr); 
   }
   fclose(fptr); 
};

void olvas(struct par stu[])
{
	
	FILE *fptr;
	 if ((fptr = fopen("program.bin","rb")) == NULL){
       printf("Error! opening file");

       // Program exits if the file pointer returns NULL.
       exit(1);
   }
   int i;
      for(i=0 ; i<10 ; i++)
   {
      fread(&stu[i], sizeof(struct par), 1, fptr); 
      printf("1: %s\n2: %d\n", stu[i].nev,stu[i].db);
   }
   fclose(fptr); 
   
	
};


void nulloz(struct par a[])
{
	int i;
	for(i=0; i<10; i++)
	{
		//printf("nulla\n");
		strcpy(a[i].nev, "\0");
		a[i].db=0;
	}
};

void cutter(char[], char[], int);
void cutter(char a[], char b[], int base)
{
	int i;
	//int max=strlen(b);
	for(i=base; i<256; i++)
	{		
		a[i-base]=b[i];
	}
	//printf("Vagott szoveg:\n%s\n%s\n",a,b);
	//printf("hosssz: %d\n", strlen(a));
};

int add(char a[],struct par stu[]);
int add(char a[], struct par stu[])
{
	int i;
	for(i=0; i<10; i++)
	{
		if(strcmp(stu[i].nev, a)==0)
		{
			 stu[i].db++;
			 return 1;
		}
	}
	for(i=0; i<10; i++)
	{
		if(stu[i].db==0)
		{
			strcpy(stu[i].nev, a);
			stu[i].db++;
			return 1;
		}
	}
	return 2;
};

int keres(char a[], struct par stu[]);
int keres(char a[], struct par stu[])
{
	int i;
	for(i=0; i<10; i++)
	{
		if(strcmp(stu[i].nev, a)==0)
		{
			int tmp=10+stu[i].db;
			return tmp;
		}
	}
	return -1;
	
}

int compare(char[], struct par stu[], int hely);
int compare(char a[], struct par stu[], int hely)
{
	char temp[256];
	strcpy(temp, "");
	//printf("Kapott ciucc hossza : %d\n", strlen(a));
	if(a[0]=='a' && a[1]=='d'&& a[2]=='d' )
	{
		
		cutter(temp,a,4);
		//int addd;
		return add(temp, stu);
	}
	
	if(a[0]=='l' && a[1]=='i' && a[2]=='s' && a[3]=='t' && a[4]=='\n')
	{
		int i;
		int n;
		for(i=0; i<10; i++)
		{
		char darab[10];
		sprintf(darab,"%d",stu[i].db);
		n = write(hely,stu[i].nev,255);
		n = write(hely,darab,255); 
		if (n < 0) {
		perror("ERROR writing to socket");
		exit(1); }
		}
	}
	if(a[0]=='l' && a[1]=='i' && a[2]=='s' && a[3]=='t')
	{
			
			cutter(temp,a,5);
			//int darabka;
			int valasz=keres(temp, stu);
			return valasz;
	}
	
	return -666;
} 

void doprocessing (int sock, struct par a[]);
void doprocessing (int sock, struct par a[]) {
	  while(1) {
   int n;
   char buffer[256];
   bzero(buffer,256);
   n = read(sock,buffer,255);
 
   if (n < 0) {
      perror("ERROR reading from socket");
      exit(1);
   }
  // kiir(a);
   olvas(a);
   printf("Here is the message: %s\n",buffer);
   int jelige;//add 1:siker 2: false
	jelige=compare(buffer, a, sock);
   char igot[50];
	if(jelige==1)
	{
		strcpy(igot, "Sikeres add");
	}
	else if(jelige==2)
	{
		strcpy(igot, "Sikertelen add");
	}
	else if(jelige>10)
	{
	strcpy(igot, "Ennyi darab volt benne: ");
	char dab[2];
	jelige=jelige-10;
	sprintf(dab,"%d",jelige);
	//itoa(jelige,dab,10);
	strcat(igot, dab);
	strcat(igot, "\n");
	}
	else if(jelige==-1)
	{
		strcpy(igot, "0 db van!");
	}
	else
	{
		strcpy(igot, "I got the message!");
	}
	int z;
	for(z=0; z<10; z++)
	{
	printf("Targy: %s db: %d \n",a[z].nev, a[z].db);
	}
	
   n = write(sock,igot,50);
   
   if (n < 0) {
      perror("ERROR writing to socket");
      exit(1);
   }
      kiir(a);
  // olvas(a);
   }
};


int main( int argc, char *argv[] ) {
   int sockfd, newsockfd, portno, clilen;
   char buffer[256];
   struct sockaddr_in serv_addr, cli_addr;
   int n, pid;
   
   /* First call to socket() function */
   sockfd = socket(AF_INET, SOCK_STREAM, 0);
   
   if (sockfd < 0) {
      perror("ERROR opening socket");
      exit(1);
   }
   
   /* Initialize socket structure */
   bzero((char *) &serv_addr, sizeof(serv_addr));
   portno = 5003;
   
   serv_addr.sin_family = AF_INET;
   serv_addr.sin_addr.s_addr = INADDR_ANY;
   serv_addr.sin_port = htons(portno);
   
   /* Now bind the host address using bind() call.*/
   if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
      perror("ERROR on binding");
      exit(1);
   }
   
   /* Now start listening for the clients, here
      * process will go in sleep mode and will wait
      * for the incoming connection
   */
   
   listen(sockfd,5);
   clilen = sizeof(cli_addr);
	struct par cuccok[10];
   nulloz(cuccok);
   while (1) {
      newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
		
      if (newsockfd < 0) {
         perror("ERROR on accept");
         exit(1);
      }
      
      /* Create child process */
      pid = fork();
		
      if (pid < 0) {
         perror("ERROR on fork");
         exit(1);
      }
      
      if (pid == 0) {
         /* This is the client process */
         //close(sockfd);
         doprocessing(newsockfd,cuccok);
         exit(0);
      }
      else {
         //close(newsockfd);
      }
		
   } /* end of while */
   printf("Vege\n");
}