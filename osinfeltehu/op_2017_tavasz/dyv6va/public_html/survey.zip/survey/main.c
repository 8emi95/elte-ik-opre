#include "view.h"

int main()
{
    view v;
    run(&v);
    return 0;
}
