* [Gyakorlat](http://oktnb127.inf.elte.hu/adagyak/01/wikis/home)

* [Megoldás](http://oktnb127.inf.elte.hu/adagyak/01/tree/master)
 

<!---

--->