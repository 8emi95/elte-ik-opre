* [Gyakorlat](http://oktnb127.inf.elte.hu/adagyak/02/wikis/home)

* [Megoldás](http://oktnb127.inf.elte.hu/adagyak/02/tree/master)

<!---
* [Megoldás](http://oktnb127.inf.elte.hu/adagyak/02/tree/master)
--->
