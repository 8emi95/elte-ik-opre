* [Gyakorlat](http://oktnb127.inf.elte.hu/adagyak/03/wikis/home)

* [Megoldás](http://oktnb127.inf.elte.hu/adagyak/03/tree/master)

<!---

--->
