#ifndef _UTILITY_
#define _UTILITY_

char * getlineQ(void) ;
void readString(char * string, unsigned int maxLength);
int readIntWithBounds(int lowerBound, int upperBound);

#endif
