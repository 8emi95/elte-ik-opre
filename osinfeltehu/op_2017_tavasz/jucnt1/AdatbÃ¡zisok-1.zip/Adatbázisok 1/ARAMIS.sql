-- skal�r �rt�ket visszaad� alk�rd�s
SELECT last_name
FROM employees
WHERE SALARY > (SELECT salary
  FROM employees
  WHERE last_name = 'Abel');

-- skal�r �rt�kekb�l �ll� t�mb�t visszaad� alk�rd�s (nem is fordul)
SELECT last_name
FROM employees
WHERE SALARY > (SELECT salary
  FROM employees
  WHERE last_name LIKE 'A%');
  
-- ez �gy m�r fordul
SELECT last_name, salary
FROM employees
WHERE SALARY > any(SELECT salary
  FROM employees
  WHERE last_name LIKE 'A%');
  
-- az sem gond, ha a skal�r �rt�k (amit az alk�rd�s visszaad) a NULL (aggreg�l� fv mindig ad vissza �rt�ket (??))
SELECT last_name, salary
FROM employees
WHERE SALARY > any(SELECT salary
  FROM employees
  WHERE last_name LIKE 'AAA%');
  
-- GROUP BY-os alk�rd�s (nem fordul �gy, mert az eredm�ny most is t�mb (persze ha csak 'Abel' lenne, akkor ok lenne)):
SELECT last_name, salary
FROM employees
WHERE SALARY > (SELECT MAX(salary)
  FROM employees
  GROUP BY last_name);
  
-- 1. Adjuk meg azon oszt�lyok nev�t �s telephely�t, amelyeknek van 1-es fizet�si kateg�ri�j� dolgoz�ja:
SELECT d.dnev, o.telephely
FROM osztaly o, dolgozo d, kategoriak k
WHERE o.oazon = d.oazon
    AND d.fizetes BETWEEN also AND felso;
  
  
  
  
--  WITH utas�t�s:
  
WITH
dept_costs  AS (
    SELECT d.department_name, SUM(e.salary) AS dept_total
    FROM   employees e JOIN departments d
    ON     e.department_id = d.department_id
    GROUP BY d.department_name),
avg_cost    AS (
    SELECT SUM(dept_total)/COUNT(*) AS dept_avg
    FROM   dept_costs)
SELECT * 
FROM   dept_costs 
WHERE  dept_total >
        (SELECT dept_avg 
        FROM avg_cost)
ORDER BY department_name;




-- hierarchkus lek�rdez�sek ("fa bej�r�s")

SELECT rowid, level, employee_id, last_name, job_id, manager_id
FROM   employees
START  WITH  employee_id = 101
CONNECT BY PRIOR manager_id = employee_id ;
-- a rowid egy pszeudooszlop, k�l�n kell k�rni hogy ezt is jelen�tse meg.
-- hasonl�an: a level is az, csak az jobban �rthet� (melyik szinten van)

COLUMN org_chart FORMAT A12
SELECT LPAD(last_name, LENGTH(last_name) + (LEVEL * 2)-2, '*-**.*')AS org_chart
FROM employees
START WITH last_name = 'King'
CONNECT BY PRIOR employee_id = manager_id;

-- IV:

SELECT *
FROM jaratok;
-- ez tulajdonk�ppen egy gr�f

select distinct honnan, hova
from jaratok
union
select j1.honnan, j2.hova
from jaratok j1, jaratok j2
where j1.hova=j2.honnan
union
select j1.honnan, j3.hova
from jaratok j1, jaratok j2, jaratok j3
where j1.hova=j2.honnan
and j2.hova=j3.honnan;
-- ...


  
  
-- saj�t pr�b�lkoz�s
  
SELECT MOD(employee_id, 2) ujnev, MAX(salary)
  FROM employees
  GROUP BY MOD(employee_id, 2);
  
  SELECT last_name LIKE 'A%', MAX(salary)
  FROM employees
  GROUP BY last_name;