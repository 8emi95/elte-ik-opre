function [osszeg, szorzat] = ossz_szor(a,b) 
% A program kisz�molja a k�t sz�m �sszeg�t �s szorzat�t.
% h�v�sa: [x1,x2] = ossz_szor(12,4)
osszeg = a + b;
szorzat = a * b;
end
