function [ B ] = ciklikus_jacobi( A, N )
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
[n,m] = size(A);
B = A;
for k = 1:N,
    for i = 1:n,
        for j=i+1:n,
            if abs(B(i,j)) > 0.0001,
                B = forgat_jo(B,i,j);
            end
        end
    end
end
end

