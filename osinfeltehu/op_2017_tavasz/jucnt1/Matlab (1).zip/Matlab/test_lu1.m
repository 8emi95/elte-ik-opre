D = diag(1:5);
S = rand(5,5)*2-1;
A = inv(S)*D*S;
