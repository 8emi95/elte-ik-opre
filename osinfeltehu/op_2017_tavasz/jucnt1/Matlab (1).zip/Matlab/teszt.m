A=[2,-1;-1,2];
B=[1,0,0;4,4,4;0,0,1];
p1=trace_msz(A);
p2=trace_msz(B);
p1
p2