x = 1:10;
y_pontos = 2 * x + 1;
y_mert =  y_pontos + (rand(1,10)-1/2)/5;
p = polyfit(x,y_mert,1)
xx = linspace(1,10,100);
pp = polyval(p,xx);
plot(x,y_mert,'*',xx,pp)
hiba = sum((y_mert - polyval(p,x)).^2)