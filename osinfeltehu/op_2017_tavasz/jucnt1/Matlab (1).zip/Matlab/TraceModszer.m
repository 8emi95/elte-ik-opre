function [ p ] = TraceModszer( A )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    n=size(A);
    B=A;
    p=[];
    s1=sum(diag(A));
    sek=[s1];
    p=[(-1)*s1,p];
    for i=2:n,
        B=B*A;
        sk=sum(diag(B));
        ossz=sek*p'+sk;
        elem=-(1/i)*ossz;
        p=[p,elem];
        sek=[sk,sek];
    end;
p=[1,p];
end