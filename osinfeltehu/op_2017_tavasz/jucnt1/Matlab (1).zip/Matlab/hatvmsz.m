function [ se,sv ] = hatvmsz( A, x0, N )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
    sv = x0;               %x_k
    for k=1:N, svuj=A*sv;  %x_[k+1]
        [m,ind] = max(abs(sv));
        se = svuj(ind)/sv(ind);
        sv = svuj / norm(svuj);
    end
end

