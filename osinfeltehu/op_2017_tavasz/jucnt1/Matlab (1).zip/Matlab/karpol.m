function [ p ] = karpol( A,x )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    n=length(x);          % x sorvektor
    xdet=zeros(1,n);
    for i=1:n, xdet(i)=det(x(i)*eye(n)-A);
    end
    y=xdet - x.^n;
    p=polyfit(x,y,n-1);
    p=[1,p];
end

