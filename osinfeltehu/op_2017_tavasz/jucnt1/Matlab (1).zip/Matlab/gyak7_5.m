vander([1,4,9]) 
x=[1,4,9]; y=[1,2,3];
p=polyfit(1,4,9);

xx=[1:0.1:9];
pp=polyval(p,xx);
yy = sqrt(xx);
subplot(2,1,1);
plot(x,y,'xb',xx,pp,'b',xx,yy,'r'); 
legend('pontok','intpol','sqrt')

kk = yy-pp;
hiba = max(abs(kk));
disp(hiba);
subplot(2,1,2);
plot(xx,kk);
title('Hiba')
