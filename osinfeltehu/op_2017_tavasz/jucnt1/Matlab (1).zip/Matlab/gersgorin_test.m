%Nem n�gyzetes m�trix
%A = ones(3,5);
%gersgorin(A);

%2x2-es m�trix
%B = [2 1; 3 7];
%gersgorin(B);

%3x3-as m�trix
C = [2 1 1; 3 10 2; -1, 4, -6];
gersgorin(C);

%Nagym�ret� m�trix
%D = magic(25);
%gersgorin(D);