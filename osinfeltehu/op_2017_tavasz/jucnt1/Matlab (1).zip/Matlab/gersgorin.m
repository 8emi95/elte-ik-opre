function [ kp, r_sor, r_oszl ] = gersgorin( A )
%A f�ggv�ny meghat�rozza a param�terk�nt kapott m�trix Gersgorin k�reit  

%M�trix n�gyzetess�g�nek ellen�rz�se
[n,m] = size(A);
if(n ~= m)
    return;
end;

%K�r�k k�z�ppontjai a m�trix diagon�lis elemei
kp=diag(A);

%K�r�k sugara a sorban/oszlopban l�v� nemdiagon�lis elemek �sszege
r_sor = [];
for i = 1:n
    r_sor(i) = 0;
    for j = 1:n
        if(i ~= j)
            r_sor(i) = r_sor(i) + abs(A(i,j));
        end;
    end;
end;

r_oszl = [];
for i = 1:n
    r_oszl(i) = 0;
    for j = 1:n
        if(i ~= j)
            r_oszl(i) = r_oszl(i) + abs(A(j,i));
        end;
    end;
end;

%K�r�k kirajzol�sa, k�l�nb�z� sz�n� kit�lt�ssel.
theta = linspace(0,2*pi);
colorVec = hsv(n);
subplot(2,1,1);
hold on;
for i = 1:n
    x = r_sor(i)*cos(theta) + kp(i);
    y = r_sor(i)*sin(theta);
    fill(x, y, colorVec(i,:));
    title('Sorokhoz tartoz� Gersgorin k�r�k');
    axis equal;
end;
hold off;

subplot(2,1,2);
hold on;
for i = 1:n
    x = r_oszl(i)*cos(theta) + kp(i);
    y = r_oszl(i)*sin(theta);
    fill(x, y, colorVec(i,:));
    title('Oszlopokhoz tartoz� Gersgorin k�r�k');
    axis equal;
end;
hold off;
%A megold�s helyess�ge k�nnyen leolvashat� a kirajzolt �br�r�l
end
