p1 = poly([4,9]);
p1 = p1/polyval(p1,1);

p2 = poly([1,9]);
p2 = p2/polyval(p2,4);

p3 = poly([1,4]);
p3 = p3/polyval(p3,9);

xx=linspace(1,9,50);
pp1 = polyval(p1,xx);
pp2 = polyval(p2,xx);
pp3 = polyval(p3,xx)
plot(xx,pp1,xx,pp2,xx,pp3);
legend('L_1','L_2','L_3');
title('Lagrange alappolinomok');