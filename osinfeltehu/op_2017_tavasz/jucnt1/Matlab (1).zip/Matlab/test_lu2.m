D = diag(1:5);
S = rand(5,5)*2-1;

[Q,R] = qr(S);
A = Q'*D*Q;