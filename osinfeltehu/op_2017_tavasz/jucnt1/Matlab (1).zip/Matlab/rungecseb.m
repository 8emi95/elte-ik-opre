function [p] = rungecseb(n)
% Az abs(x) fv-t interpol�lja Csebisev alappontrendszeren
% H�v�sa: p = abscseb(11)


k = [0:n]; 
x = cos((1+2*k)*pi/2/(n+1)); 
y = (1./(1+25*x.*x));
p = polyfit(x,y,n);
xx = linspace(-1,1,100);
yy = polyval(p,xx); 
yf = (1./(1+25*xx.*xx));
plot(x,y,'x',xx,yy,xx,yf);
legend('pontok','intpol','fv')
end
