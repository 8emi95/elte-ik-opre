%not-a-knot peremfelt�tel Hernite
xx = linspace(-1,5,100);
yy = sin(pi/2*xx);
x =(-1:5)
y =[0,sin(pi/2*x),0];
ss = spline(x,y,xx);
plot(xx,yy,xx,ss);
hiba = abs(max(yy - ss))