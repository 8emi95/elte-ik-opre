function [ B ] = lualg( A,N )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
B = A;
for k=1:N;
    [L,U] = lu(B);
    B = U * L;
end
end

