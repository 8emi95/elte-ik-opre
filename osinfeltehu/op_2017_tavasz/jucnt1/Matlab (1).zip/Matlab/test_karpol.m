A=[2,-1;-1,2]
x=[0,2]
p=karpol(A,x)