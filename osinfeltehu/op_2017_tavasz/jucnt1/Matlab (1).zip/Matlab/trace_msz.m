function [ p ] = trace_msz( A )
%A f�ggv�ny a m�trix diagon�lis�nak �sszeg�nek (trace) seg�ts�g�vel
%sz�molja ki a karakterisztikus polinomj�t
    n=size(A);
    Seged = A;
    p=[];
    newS=trace(A);
    newP=-newS;
    s=[newS];
    p=[newP];
    for k=2:n,
        Seged=Seged*A;
        newS=trace(Seged);
        sum=s*p'+newS;
        newP=-(1/k)* sum;
        p=[p,newP];
        s=[newS,s];
    end;
p=[1,p];
end
