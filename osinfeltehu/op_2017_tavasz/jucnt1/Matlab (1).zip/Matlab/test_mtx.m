D=diag([1,2,3,4,5])
X=rand(5,5)*(-1);
A=inv(X) * D * X;