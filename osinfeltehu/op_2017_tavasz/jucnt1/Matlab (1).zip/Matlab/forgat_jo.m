function [B] = forgat_jo(A,i,j)
% Nem stabil �s sokat sz�mol� verzi�. 

n = max(size(A));

u = 2* A(i,j);
v = A(j,j)- A(i,i);
w = sqrt(u*u + v*v);

c=sqrt((w+v*sign(u))/(2*w));
s=(u*sign(u))/(2*c*w);

for l = 1:n;
    G(i,j) = c * A(i,j) - s * A(j,l);
    G(j,l) = s * A(i,l) + c * A(j,l);
    
    B(l,i) = c * G(l,i) - s * G(l,j);
    B(l,j) = s * G(l,i) + c * G(l,j);   
end;

%B=Q'*A*Q;
%B(i,j)=0;
%B(j,i)=0;
end
