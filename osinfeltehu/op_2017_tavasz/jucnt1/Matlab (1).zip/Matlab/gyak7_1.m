vander([1,4,9]) 
x=[1,4,9]; y=[1,2,3];
p=vander([1,4,9])\y'
xx=[1:0.1:9]; pp=polyval(p,xx);
yy = sqrt(xx);
plot(x,y,'xb',xx,pp,'b',xx,yy,'r'); 
legend('pontok','intpol','sqrt')
