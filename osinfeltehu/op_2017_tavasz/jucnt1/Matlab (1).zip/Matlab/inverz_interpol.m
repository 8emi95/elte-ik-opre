% els� l�p�s:
x=[0,1/2,1]
y=sin(x)-1/2
p=polyfit(y,x,2)
polyval(p,0)
x(1)=polyval(p,0)
x % az �j alappontok a 2. l�p�s kezdet�n
fzero(@(x) sin(x)-1/2,0,1) % ellen�rz�s

% m�sodik l�p�s:
x=[0.5236,1/2,1]
y=sin(x)-1/2
p=polyfit(y,x,2)
polyval(p,0)
x(2)=polyval(p,0)
x % az �j alappontok a 3. l�p�s kezdet�n
fzero(@(x) sin(x)-1/2,0,1) % ellen�rz�s

% harmadik l�p�s:
x=[0.5236,1/2,0.5236]
y=sin(x)-1/2
p=polyfit(y,x,2)
polyval(p,0)
x(3)=polyval(p,0)
x % az �j alappontok a 4. l�p�s kezdet�n
fzero(@(x) sin(x)-1/2,0,1) % ellen�rz�s