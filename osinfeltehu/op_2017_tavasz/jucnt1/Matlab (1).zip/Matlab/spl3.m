  function P = spl3(x,y,m1,m2)
  n = length(x);
  ms1 = m1; 
  ms2 = m2;
  if length(y) == n, 
    P = zeros(n-1,4);
    for i = 1:n-1, h = x(i+1)-x(i);
                 P(i,4) = y(i); 
                 P(i,3) = ms1; 
                 P(i,2) = ms2/2;
                 P(i,1) = (y(i+1)-y(i)-ms1*h-h^2*ms2/2)/h^3;
                 ms1 = P(i,3)+2*h*P(i,2)+3*h^2*P(i,1);
                 ms2 = 2*P(i,2)+6*h*P(i,1);
    end;
    xx = x(1); 
    yy = y(1);
    for i = 1:n-1, xs = linspace(x(i),x(i+1),20);
                 xx = [xx,xs];
                 p = P(i,:); 
                 ss = xs-x(i)*ones(size(xs));
                 ys = polyval(p,ss); 
                 yy = [yy,ys];
    end;
    plot(x,y,'o',xx,yy,'b');
  end;
