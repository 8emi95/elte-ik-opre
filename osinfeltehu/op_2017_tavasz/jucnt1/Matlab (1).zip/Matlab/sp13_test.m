x = 0:12;
y = sin(pi/2*x);
xx = linspace(0,12,50);
yy = sin(pi/2*xx);
plot(xx,yy,'r')
hold on
spl3(x,y,pi/2,0);
hold off
