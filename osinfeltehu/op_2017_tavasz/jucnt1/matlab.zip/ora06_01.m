x=[1,4,9];y=[1,2,3];
p=vander([1,4,9])\y'

xx=[1:0.1:9]; yy = sqrt(xx); tt=polyval(p,xx);
plot(x,y,'xb',xx,tt,'r',xx,yy); 
legend('pontok','intpol', 'sqrt')