x=[1,4,9];y=[1,2,3];
p=polyfit(x,y,2);

xx=[1:0.1:9]; yy = sqrt(xx); tt=polyval(p,xx);
subplot(2,1,1)
plot(x,y,'xb',xx,tt,'r',xx,yy); 
legend('pontok','intpol', 'sqrt')

hh = yy - tt;
hiba = max(abs(hh));
disp(hiba)

subplot(2,1,2)
plot(xx,hh)
title('Hibafv')