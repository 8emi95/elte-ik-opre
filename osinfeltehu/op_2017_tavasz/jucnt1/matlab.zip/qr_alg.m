function [ B ] = qr_alg( A, N )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
B = A;
    for k = 1:N
        [Q,R] = qr(B);
        B = R * Q;
    end
end

