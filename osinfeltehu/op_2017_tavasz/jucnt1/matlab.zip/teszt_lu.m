D = diag(5:-1:1);
S = rand(5,5) * 2 -1;
A = inv(S) * D * S;

%szimm
A = A' * A

%szimm
%[Q,R] = qr(S);
%A = Q'*D*Q;