p1 = poly([4,9]);
p1 = p1/polyval(p1,1);

p2 = poly([1,9]);
p2 = p2/polyval(p2,4);

p3 = poly([1,4]);
p3 = p3/polyval(p3,9);

xx=linspace(1,9,100);
pp1 = polyval(p1,xx);
pp2 = polyval(p2,xx);
pp3 = polyval(p3,xx);
plot(xx,pp1,xx,pp2,xx,pp3)
legend('L1','L2','L3')
title('Lagrange alappolinomok')