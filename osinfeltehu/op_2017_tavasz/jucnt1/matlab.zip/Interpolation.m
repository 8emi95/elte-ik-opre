function [ p ] = Interpolation( A, x)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
   n = length(x);
   %hf az A m�rete
   xdet = zeros(1,n); %x sorvektor
   
   for i = 1:n xdet(i) = det(x(i) * eye(n) - A);
   end
   
   y = xdet - x.^n;
   p = polyfit(x,y,n-1); %n-1, mert fh 1
   p = [1,p];
end

