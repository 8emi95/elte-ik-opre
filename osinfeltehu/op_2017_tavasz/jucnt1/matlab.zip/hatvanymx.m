function [ se,sv ] = hatvanymx( A,x0,N)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
    sv = x0; % xk
    for k=1:N
        svuj = A * sv; % x_[k+1]
        [m,ind] = max(abs(sv));
        se = svuj(ind) / sv(ind);
        sv = svuj / (norm(svuj));
    end
end

