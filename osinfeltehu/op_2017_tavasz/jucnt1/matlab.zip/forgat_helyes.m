function [ B ] = forgat_helyes( A,i,j )
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here
[n,m]=size(A);
u = 2 * A(i,j);
v = A(j,j) - A(i,i);
w = sqrt(u^2 + v^2);
c = sqrt((w + v * sign(u))/(2*w));
s = (u * sign(u))/ (2*c*w);
%B=Q'*A*Q;

G = A;
    for l = 1:n,
        G(i,l) = c * A(i,l) - s * A(j,l);
        G(j,l) = s * A(i,l) + c * A(j,l);
    end
B = G;
    for l = 1:n,
        B(l,i) = c * G(l,i) - s * G(l,j);
        B(l,j) = s * G(l,i) + c * G(l,j);
    end
end