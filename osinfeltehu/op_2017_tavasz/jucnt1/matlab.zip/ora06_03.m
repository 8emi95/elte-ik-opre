x=[0:10]
y=sin(x)
plot(x,y,'x')
xx=linspace(0,10,100);
yy=interp1(x,y,xx);
plot(x,y,'x',xx,yy,'.')
