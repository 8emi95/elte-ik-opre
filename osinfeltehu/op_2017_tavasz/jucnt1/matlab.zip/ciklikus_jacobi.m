function [ B ] = ciklikus_jacobi( A,N )
%UNTITLED11 Summary of this function goes here
%   Detailed explanation goes here
[n,m] = size(A);
B = A;
    for k = 1:N,
        for i = 1:n,
            for j = i+1:n,
                if abs(B(i,j))>0.0001,
                    B = forgat_helyes(B,i,j)
                end
                osszeg = norm(A,'fro')^2 - norm(diag(B))^2;
                disp(osszeg)    
            end
        end
    end
end

