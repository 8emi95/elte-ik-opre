D = diag([1,2,3,4,5]);
X = rand(5,5) * 2 -1; %-1,1
A = inv(X) * D * X;
x0 = rand(5,1) * 2 -1;
[se,sv] = hatvanymx(A,x0,22)
B = A - 2*eye(5);
[se,sv] = hatvanymx(B,x0,22)